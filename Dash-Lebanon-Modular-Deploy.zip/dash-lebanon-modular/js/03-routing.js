/* =========================================================
   ROUTING TABLE — maps internal page names <-> real URLs
   and sets the browser tab title per page.
========================================================= */
const ROUTES=[
  {page:'home',        pattern:/^\/$/,                         toPath:()=>'/'},
  {page:'home',        pattern:/^\/category\/([^/]+)$/,         toPath:d=>`/category/${d}`, dataFrom:m=>({offers:false,catSlug:m[1]})},
  {page:'cart',        pattern:/^\/cart$/,                      toPath:()=>'/cart'},
  {page:'checkout',    pattern:/^\/checkout$/,                  toPath:()=>'/checkout'},
  {page:'success',     pattern:/^\/order-success$/,             toPath:()=>'/order-success'},
  {page:'wishlist',    pattern:/^\/favorites$/,                 toPath:()=>'/favorites'},
  {page:'orders',      pattern:/^\/orders$/,                    toPath:()=>'/orders'},
  {page:'order-detail',pattern:/^\/order\/([^/]+)$/,            toPath:d=>`/order/${d}`, dataFrom:m=>m[1]},
  {page:'points',      pattern:/^\/points$/,                    toPath:()=>'/points'},
  {page:'account',     pattern:/^\/account$/,                   toPath:()=>'/account'},
  {page:'account',     pattern:/^\/login$/,                     toPath:()=>'/login'},
  {page:'contact',     pattern:/^\/contact$/,                   toPath:()=>'/contact'},
  {page:'product',     pattern:/^\/product\/([^/]+)$/,          toPath:d=>`/product/${d}`, dataFrom:m=>m[1]},
  {page:'admin-login', pattern:/^\/admin\/login\/?$/,              toPath:()=>'/admin/login'},
  {page:'admin',       pattern:/^\/admin\/?([a-z-]*)$/,         toPath:d=>'/admin'+(d&&d!=='overview'?'/'+d:''), dataFrom:m=>m[1]||'overview'},
  {page:'home',        pattern:/^\/products$/,                  toPath:()=>'/products', dataFrom:()=>({forceGrid:true})},
];
function pageTitle(){
  const st=S.settings||{};const brand=st.store_name||'Dash Lebanon';
  switch(S.page){
    case'home':return S.forceGrid||S.cat!=='all'||S.offersOnly?`${catLabel(S.cat)} | ${brand}`:`${brand} | ${st.hero_title||'Home'}`;
    case'product':{const p=S.products.find(x=>x.id===S.data);return p?`${p.name} | ${brand}`:brand;}
    case'cart':return`Shopping Cart | ${brand}`;
    case'checkout':return`Checkout | ${brand}`;
    case'success':return`Order Confirmed | ${brand}`;
    case'wishlist':return`Favorites | ${brand}`;
    case'orders':return`My Orders | ${brand}`;
    case'order-detail':return`Order Details | ${brand}`;
    case'points':return`My Points | ${brand}`;
    case'account':return`${S.session?'My Account':'Sign In'} | ${brand}`;
    case'contact':return`Contact Us | ${brand}`;
    case'admin-login':return`Admin Login | ${brand}`;
    case'admin':return`Admin · ${adminSectionLabel(S.adminSection)} | ${brand}`;
    default:return brand;
  }
}
function adminSectionLabel(s){return({overview:'Overview',orders:'Orders',products:'Products',categories:'Categories',ai:'إعدادات الذكاء الاصطناعي',settings:'Store Settings',messages:'Messages',reviews:'Reviews'})[s]||'Admin'}
function pathForRoute(page,data){
  if(page==='home'){
    if(S.offersOnly||S.forceGrid||S.cat!=='all'||S.search)return S.cat&&S.cat!=='all'?`/category/${S.cat}`:'/products';
    return'/';
  }
  if(page==='product')return`/product/${data}`;
  if(page==='order-detail')return`/order/${data}`;
  if(page==='wishlist')return'/favorites';
  if(page==='admin-login')return'/admin/login';
  if(page==='admin')return'/admin'+(data&&data!=='overview'?'/'+data:'');
  const known=['cart','checkout','success','orders','points','account','contact'];
  if(known.includes(page))return page==='success'?'/order-success':'/'+page;
  return'/';
}

function esc(s){if(s==null)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function fmt(n){const x=parseFloat(n);return isNaN(x)?'$0.00':'$'+x.toFixed(2)}
function fmtLBP(n){if(!S.settings)return'';return Math.round(parseFloat(n)*S.settings.currency_rate).toLocaleString('en')+' LBP'}
let toastTimer;
function toast(msg){const el=document.getElementById('toast');clearTimeout(toastTimer);el.textContent=msg;el.classList.add('show');toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function saveCart(){localStorage.setItem('dl_cart',JSON.stringify(S.cart))}
function cartCount(){return S.cart.reduce((s,i)=>s+i.qty,0)}
function cartSub(){return parseFloat(S.cart.reduce((s,i)=>s+i.price*i.qty,0).toFixed(2))}
function cartDelivery(){return S.cart.length?4:0}
function cartTotal(){return parseFloat((cartSub()+cartDelivery()-(S.appliedDiscount||0)).toFixed(2))}
function updateCartBadge(){const c=cartCount();const b=document.getElementById('cart-badge');b.textContent=c;b.classList.toggle('hide',!c)}
