/* =========================================================
   GLOBAL STATE
========================================================= */
const S={
  page:'home',data:null,history:[],
  dark: localStorage.getItem('dl_dark')!==null ? localStorage.getItem('dl_dark')==='1' : true,
  settings:null,categories:[],products:[],
  session:null,profile:null,isAdmin:false,
  deliveryLocation:null,
  cart:JSON.parse(localStorage.getItem('dl_cart')||'[]'),
  wishlist:[],           // product ids
  cat:'all',search:'',offersOnly:false,sort:'def',forceGrid:false,
  dqty:1,buyMode:'normal',
  currentOrder:null,
  adminSection:'overview',
  aiPublic:null,          // {enabled, assistant_name, welcome_message}
};
