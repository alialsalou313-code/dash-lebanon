/* =========================================================
   WISHLIST PAGE
========================================================= */
async function pWishlist(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your wishlist');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data}=await sb.from('wishlists').select('product_id').eq('user_id',S.session.user.id);
  const ids=(data||[]).map(w=>w.product_id);
  const items=S.products.filter(p=>ids.includes(p.id));
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-title" style="margin-bottom:14px">Wishlist (${items.length})</div>
    ${!items.length?`<div class="empty-box"><div class="empty-ico">♡</div><div class="empty-ttl">Your wishlist is empty</div><div class="empty-sub">Tap the heart on any product to save it here.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div>`:
    `<div class="grid">${items.map(p=>productCardHTML(p)).join('')}</div>`}
  </div>`;
}
function authRequiredHTML(action){
  return `<div class="page"><div class="empty-box"><div class="empty-ico">🔒</div><div class="empty-ttl">Sign in to ${esc(action)}</div><div class="empty-sub">Create a free account or log in to continue.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="nav('account')">Sign in</button></div></div>`;
}
