/* =========================================================
   ROUTER
========================================================= */
function nav(page,data=null,push=true){
  S.page=page;S.data=data;
  if(page==='admin')S.adminSection=data||'overview';
  if(page==='home'&&data&&data.offers){S.offersOnly=true;S.cat='offers';S.forceGrid=true}
  if(page!=='product'){S.dqty=1;S.buyMode='normal'}
  if(page==='admin'&&!guardAdmin())return;
  render();
  window.scrollTo(0,0);updateChromeAuth();closeDrawer();
  syncUrl(push);
}
let inAppNavDepth=0;
function syncUrl(push){
  const path=pathForRoute(S.page,S.page==='admin'?S.adminSection:S.data);
  const state={page:S.page,data:S.data,adminSection:S.adminSection,cat:S.cat,offersOnly:S.offersOnly,forceGrid:S.forceGrid,search:S.search};
  if(push&&location.pathname!==path){history.pushState(state,'',path);inAppNavDepth++}
  else history.replaceState(state,'',path);
  document.title=pageTitle();
}
let hiddenAdminClicks=0,hiddenAdminTimer=null;
function handleHiddenAdminClick(){
  hiddenAdminClicks++;
  clearTimeout(hiddenAdminTimer);
  hiddenAdminTimer=setTimeout(()=>{hiddenAdminClicks=0},3000);
  if(hiddenAdminClicks>=5){
    hiddenAdminClicks=0;
    clearTimeout(hiddenAdminTimer);
    nav('admin-login');
  }else{
    resetHome();
  }
}
function guardAdmin(silent=false){
  if(!S.session){if(!silent){toast('Please sign in to access the Admin Dashboard');nav('admin-login')}return false}
  if(!S.isAdmin){if(!silent){toast('This account does not have admin access');nav('admin-login')}return false}
  return true;
}
function resetHome(){S.forceGrid=false;S.cat='all';S.search='';S.offersOnly=false;nav('home');closeDrawer()}
function viewAllCategory(slug){S.cat=slug;S.offersOnly=(slug==='offers');S.forceGrid=true;S.search='';nav('home');}
function openSearch(){viewAllCategory('all');setTimeout(()=>{const f=document.getElementById('search-field');if(f)f.focus()},60)}
function goBack(){if(inAppNavDepth>0){history.back()}else{nav('home',null,false)}}
function routeFromLocation(){
  const path=location.pathname;
  for(const r of ROUTES){
    const m=path.match(r.pattern);
    if(m){
      let data=r.dataFrom?r.dataFrom(m):null;
      if(r.page==='home'&&data&&data.catSlug){S.cat=data.catSlug;S.offersOnly=(data.catSlug==='offers');S.forceGrid=true;data=null}
      if(r.page==='home'&&data&&data.forceGrid){S.forceGrid=true;data=null}
      return{page:r.page,data};
    }
  }
  return{page:'home',data:null};
}
window.addEventListener('popstate',(e)=>{
  if(inAppNavDepth>0)inAppNavDepth--;
  const st=e.state;
  if(st){S.page=st.page;S.data=st.data;S.adminSection=st.adminSection||'overview';S.cat=st.cat||'all';S.offersOnly=!!st.offersOnly;S.forceGrid=!!st.forceGrid;S.search=st.search||'';}
  else{const r=routeFromLocation();S.page=r.page;S.data=r.data;if(r.page==='admin')S.adminSection=r.data||'overview';}
  if(S.page==='admin'&&!guardAdmin())return;
  render();updateChromeAuth();document.title=pageTitle();
});
function openDrawer(){document.getElementById('drawer').classList.add('open');document.getElementById('drawer-ov').classList.add('open')}
function closeDrawer(){document.getElementById('drawer').classList.remove('open');document.getElementById('drawer-ov').classList.remove('open')}

const app=()=>document.getElementById('app');
function showFooterCart(hide){document.getElementById('site-footer').classList.toggle('hide',hide)}

function render(){
  const noFooter=['cart','checkout'];
  showFooterCart(noFooter.includes(S.page));
  document.body.classList.toggle('has-sticky-bar',noFooter.includes(S.page));
  switch(S.page){
    case'home':app().innerHTML=pHome();bindHome();break;
    case'product':pProduct();break;
    case'cart':app().innerHTML=pCart();break;
    case'checkout':app().innerHTML=pCheckout();break;
    case'success':app().innerHTML=pSuccess();break;
    case'orders':pOrders();break;
    case'order-detail':pOrderDetail();break;
    case'wishlist':pWishlist();break;
    case'points':pPoints();break;
    case'account':pAccount();break;
    case'contact':app().innerHTML=pContact();break;
    case'admin-login':pAdminLogin();break;
    case'admin':pAdmin();break;
    default:app().innerHTML=pHome();bindHome();
  }
  document.title=pageTitle();
}
