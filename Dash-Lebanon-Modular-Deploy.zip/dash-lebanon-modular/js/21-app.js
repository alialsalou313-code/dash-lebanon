/* =========================================================
   PATCH render() to call renderAuthBody after auth page renders
========================================================= */
const _origRender=render;
render=function(){_origRender();if(S.page==='account'&&!S.session)renderAuthBody()};



/* =========================================================
   MODULAR APP ENHANCEMENTS
========================================================= */
function toggleMobilePlus(){
  const btn=document.getElementById('mobile-nav-plus'),items=document.getElementById('mobile-nav-items');
  if(!btn||!items)return;
  const open=!items.classList.contains('open');items.classList.toggle('open',open);btn.classList.toggle('on',open);items.setAttribute('aria-hidden',String(!open));
}
function updateMobileNav(){
  document.querySelectorAll('[data-mnav]').forEach(el=>el.classList.toggle('on',el.dataset.mnav===S.page));
}
const _dashOriginalNav=window.nav;
window.nav=function(page,data,changeUrl=true){
  const result=_dashOriginalNav? _dashOriginalNav(page,data,changeUrl):undefined;
  setTimeout(updateMobileNav,0);return result;
};

/* AI image attachment: keeps images client-side until the AI request. */
let aiPendingImages=[];
function aiHandleImages(event){
  const files=Array.from(event.target.files||[]).filter(f=>f.type.startsWith('image/')).slice(0,4);
  if(!files.length)return;
  Promise.all(files.map(file=>new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve({name:file.name,type:file.type,dataUrl:r.result});r.onerror=reject;r.readAsDataURL(file)}))).then(items=>{
    aiPendingImages=items;toast(`${items.length} image${items.length>1?'s':''} attached`);renderAiBody();
  }).catch(()=>toast('Could not attach the image.'));
}

/* Patch AI call to include attached images without exposing provider keys. */
const _dashOriginalAiCallEdge=window.aiCallEdge;
window.aiCallEdge=async function(text){
  if(!aiPendingImages.length)return _dashOriginalAiCallEdge(text);
  const originalInvoke=sb.functions.invoke.bind(sb.functions);
  // The existing AI function accepts JSON. We temporarily wrap invoke so the original function receives images.
  sb.functions.invoke=async function(name,opts){
    if(name===AI_FUNCTION_NAME && opts?.body){opts={...opts,body:{...opts.body,images:aiPendingImages.map(x=>({type:x.type,dataUrl:x.dataUrl}))}}}
    return originalInvoke(name,opts);
  };
  try{return await _dashOriginalAiCallEdge(text)}finally{sb.functions.invoke=originalInvoke;aiPendingImages=[];const input=document.getElementById('ai-image-input');if(input)input.value='';}
};

/* The old inline render patch remains compatible; this only refreshes mobile state. */
const _dashOldRender=window.render;
if(typeof _dashOldRender==='function'){
  window.render=function(){const r=_dashOldRender.apply(this,arguments);setTimeout(updateMobileNav,0);return r};
}
