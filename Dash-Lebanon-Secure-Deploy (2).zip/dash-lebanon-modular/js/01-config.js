/* =========================================================
   CONFIG
========================================================= */
const SUPABASE_URL='https://urlkkwxmalhyvycowwxz.supabase.co';
const DELIVERY_REVERSE_GEOCODING_READY=false; // Enable only after GEOAPIFY_API_KEY is set as a Supabase secret.
const SUPABASE_KEY='sb_publishable_VT8O9ta4dafI1nCsQaCcGQ_3qdu8RAP'; // publishable key: safe in the browser; protection comes from RLS
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
const AI_FUNCTION_NAME='ai-chat';
// Supabase Edge Function name (see /supabase/functions/ai-chat)
