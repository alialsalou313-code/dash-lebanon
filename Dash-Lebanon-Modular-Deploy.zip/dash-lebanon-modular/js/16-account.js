/* =========================================================
   ACCOUNT — direct email/password auth (OTP/Firebase removed)
========================================================= */
let authTab='login';
function pAccount(){
  if(!S.session){app().innerHTML=pAuthForms();renderAuthBody();return}
  renderAccountLoggedIn();
}
function pAuthForms(){return `<div class="page" style="max-width:440px">
  <button class="back-link" onclick="goBack()">← Back</button>
  <div class="card form-card"><div class="auth-tabs" id="auth-tabs-nav">
    <button class="auth-tab ${authTab==='login'?'on':''}" onclick="setAuthTab('login')">Log in</button>
    <button class="auth-tab ${authTab==='register'?'on':''}" onclick="setAuthTab('register')">Register</button>
    <button class="auth-tab ${authTab==='forgot'?'on':''}" onclick="setAuthTab('forgot')">Forgot</button>
  </div><div id="auth-msg"></div><div id="auth-body"></div></div></div>`}
function setAuthTab(t){authTab=t;render();renderAuthBody()}
function renderAuthBody(){
 const body=document.getElementById('auth-body');if(!body)return;
 if(authTab==='login') body.innerHTML=`<div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="lg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="lg-pass" type="password" autocomplete="current-password"></div><button class="btn btn-primary" id="lg-btn" onclick="doLogin()">Log in</button>`;
 else if(authTab==='register') body.innerHTML=`<div class="frow2"><div class="fgroup"><label class="flabel">First name <span class="req">*</span></label><input class="finput" id="rg-fname"></div><div class="fgroup"><label class="flabel">Last name <span class="req">*</span></label><input class="finput" id="rg-lname"></div></div><div class="fgroup"><label class="flabel">Username <span class="req">*</span></label><input class="finput" id="rg-username"></div><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="rg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Phone number</label><input class="finput" id="rg-phone" type="tel" autocomplete="tel"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="rg-pass" type="password" autocomplete="new-password"></div><button class="btn btn-primary" id="rg-btn" onclick="doRegister()">Create account</button>`;
 else body.innerHTML=`<p class="muted-note">Enter your email and we'll send you a reset link.</p><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="fg-email" type="email" autocomplete="email"></div><button class="btn btn-primary" id="fg-btn" onclick="doForgot()">Send reset link</button>`;
}
function authMsg(text,ok){const el=document.getElementById('auth-msg');if(el)el.innerHTML=text?`<div class="alert ${ok?'alert-ok':'alert-err'}">${esc(text)}</div>`:''}
async function doLogin(){const email=document.getElementById('lg-email')?.value.trim(),pass=document.getElementById('lg-pass')?.value;if(!email||!pass)return authMsg('Please fill in all fields',false);const btn=document.getElementById('lg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.signInWithPassword({email,password:pass});btn.disabled=false;btn.textContent='Log in';if(error)return authMsg(error.message,false);await loadProfileAndWishlist();toast('Welcome back!');nav('account',null,false)}
async function doRegister(){const fname=document.getElementById('rg-fname').value.trim(),lname=document.getElementById('rg-lname').value.trim(),username=document.getElementById('rg-username').value.trim(),email=document.getElementById('rg-email').value.trim(),phone=document.getElementById('rg-phone').value.trim(),pass=document.getElementById('rg-pass').value;if(!fname||!lname||!username||!email||!pass)return authMsg('Please fill in all required fields',false);if(pass.length<6)return authMsg('Password must be at least 6 characters',false);const btn=document.getElementById('rg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{data,error}=await sb.auth.signUp({email,password:pass,options:{data:{first_name:fname,last_name:lname,username,phone}}});btn.disabled=false;btn.textContent='Create account';if(error)return authMsg(error.message,false);if(data.session){S.session=data.session;await loadProfileAndWishlist();toast('Welcome to Dash Lebanon!');nav('account',null,false)}else{authMsg('Account created. You can log in now.',true);setAuthTab('login')}}
async function doForgot(){const email=document.getElementById('fg-email')?.value.trim();if(!email)return authMsg('Please enter your email',false);const btn=document.getElementById('fg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});btn.disabled=false;btn.textContent='Send reset link';authMsg(error?error.message:'If that email is registered, a reset link is on its way.',!error)}

function renderAccountLoggedIn(){
  const p=S.profile||{};
  app().innerHTML=`<div class="page" style="max-width:520px">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="profile-hero">
      <div class="avatar-circ">${esc((p.first_name||'U')[0])}</div>
      <div><div style="font-weight:800">${esc(p.first_name||'')} ${esc(p.last_name||'')}</div><div style="color:var(--muted);font-size:.83rem;font-family:var(--font-m)">@${esc(p.username||'')}</div></div>
    </div>
    <div class="card" style="padding:4px">
      <div class="menu-list">
        <div class="menu-item" onclick="nav('orders')">📦 My Orders <span>›</span></div>
        <div class="menu-item" onclick="nav('wishlist')">♡ Wishlist <span>›</span></div>
        <div class="menu-item" onclick="nav('points')">★ My Points (${p.loyalty_points||0}) <span>›</span></div>
        <div class="menu-item" onclick="openDeliveryLocationEditor()">📍 Delivery location <span>${S.deliveryLocation?.confirmed_at?'Edit':'Add'} ›</span></div>
        <div class="menu-item" onclick="openEditProfile()">✎ Edit profile <span>›</span></div>
      </div>
    </div>
    <button class="btn btn-danger" style="margin-top:14px" onclick="doLogout()">Log out</button>
  </div>`;
}
let deliveryPendingCoordinates=null,deliveryLocationReturnToAi=false;
function openDeliveryLocationEditor(returnToAi=false){
  deliveryLocationReturnToAi=returnToAi;
  deliveryPendingCoordinates=S.deliveryLocation?.latitude!=null&&S.deliveryLocation?.longitude!=null?{latitude:S.deliveryLocation.latitude,longitude:S.deliveryLocation.longitude}:null;
  const loc=S.deliveryLocation||{};
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">📍 موقع التوصيل</div>
    <p class="muted-note" style="margin-bottom:12px">أدخل موقع التوصيل يدوياً${DELIVERY_REVERSE_GEOCODING_READY?'، أو استخدم موقعك الحالي بعد موافقة المتصفح':''}. راجع العنوان وعدّله قبل الحفظ.</p>
    ${DELIVERY_REVERSE_GEOCODING_READY?`<div class="delivery-location-actions" style="margin:0 0 12px"><button class="btn btn-ghost btn-sm" id="delivery-current-location" onclick="useCurrentDeliveryLocation()">استخدام موقعي الحالي</button></div>`:''}
    ${DELIVERY_REVERSE_GEOCODING_READY?`<div class="muted-note" style="margin-bottom:10px">عند اختيار موقعك الحالي، تُرسل الإحداثيات إلى Geoapify عبر الخادم لتحويلها إلى عنوان. تذكر سياسة Geoapify أن بيانات طلب الـAPI، ومنها الإحداثيات، تُحفظ عادةً حتى 24 ساعة للطلبات الناجحة. <a href="https://www.geoapify.com/privacy-policy/" target="_blank" rel="noopener">سياسة الخصوصية</a>. يمكنك إدخال العنوان يدوياً بدلاً من ذلك.</div>`:''}
    <div id="delivery-location-status" class="muted-note" style="min-height:18px;margin-bottom:8px"></div>
    ${DELIVERY_REVERSE_GEOCODING_READY?`<div class="muted-note" style="margin-bottom:10px">Powered by <a href="https://www.geoapify.com/" target="_blank" rel="noopener">Geoapify</a> · © OpenStreetMap contributors</div>`:''}
    <div class="fgroup"><label class="flabel">المحافظة / المدينة <span class="req">*</span></label><input class="finput" id="dl-city" value="${esc(loc.city||'')}" oninput="deliveryPendingCoordinates=null"></div>
    <div class="fgroup"><label class="flabel">المنطقة / الحي</label><input class="finput" id="dl-district" value="${esc(loc.district||'')}" oninput="deliveryPendingCoordinates=null"></div>
    <div class="fgroup"><label class="flabel">العنوان التفصيلي <span class="req">*</span></label><textarea class="ftextarea" id="dl-address" oninput="deliveryPendingCoordinates=null">${esc(loc.full_address||'')}</textarea></div>
    <div class="muted-note" style="margin-bottom:12px">لن يُطلب الموقع بالخلفية. رسوم التوصيل ثابتة: $4.00 لكل لبنان.</div>
    <button class="btn btn-primary" id="dl-save" onclick="saveDeliveryLocation()">تأكيد وحفظ العنوان</button>
    ${S.deliveryLocation?`<button class="btn btn-ghost" style="margin-top:8px" onclick="deleteDeliveryLocation()">إزالة العنوان المحفوظ</button>`:''}
    <button class="btn btn-ghost" style="margin-top:8px" onclick="closeModal()">إلغاء</button>
  </div></div>`;
}
async function useCurrentDeliveryLocation(){
  const status=document.getElementById('delivery-location-status');
  if(!navigator.geolocation){status.textContent='المتصفح لا يدعم تحديد الموقع. أدخل العنوان يدوياً.';return}
  if(!DELIVERY_REVERSE_GEOCODING_READY){status.textContent='خدمة تحويل الموقع إلى عنوان لم تُفعّل بعد. يمكنك إدخال العنوان يدوياً الآن.';return}
  const button=document.getElementById('delivery-current-location');button.disabled=true;status.textContent='بانتظار موافقة المتصفح على الموقع…';
  navigator.geolocation.getCurrentPosition(async position=>{
    try{
      const latitude=position.coords.latitude,longitude=position.coords.longitude;
      const{data,error}=await sb.functions.invoke('reverse-geocode',{body:{latitude,longitude}});
      if(error||!data?.address)throw error||new Error('address_not_found');
      deliveryPendingCoordinates={latitude,longitude};
      document.getElementById('dl-city').value=data.city||data.region||'';
      document.getElementById('dl-district').value=data.district||'';
      document.getElementById('dl-address').value=data.address||'';
      status.textContent='راجع العنوان وعدّله قبل التأكيد.';
    }catch(error){console.error('Reverse geocoding failed:',error);status.textContent='تعذر تحويل موقعك إلى عنوان. يمكنك إدخال العنوان يدوياً.'}
    finally{button.disabled=false}
  },error=>{status.textContent=error.code===1?'لم تسمح بمشاركة موقعك. أدخل العنوان يدوياً أو اسمح للموقع من المتصفح.':'تعذر تحديد الموقع. أدخل العنوان يدوياً.';button.disabled=false},{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}
async function saveDeliveryLocation(){
  const city=document.getElementById('dl-city').value.trim(),district=document.getElementById('dl-district').value.trim(),full_address=document.getElementById('dl-address').value.trim();
  if(!city||!full_address){toast('أدخل المدينة والعنوان التفصيلي');return}
  const now=new Date().toISOString();
  const loc={user_id:S.session?.user?.id||null,city,district,full_address,latitude:deliveryPendingCoordinates?.latitude??null,longitude:deliveryPendingCoordinates?.longitude??null,source:deliveryPendingCoordinates?'geolocation':'manual',confirmed_at:now,updated_at:now};
  const button=document.getElementById('dl-save');button.disabled=true;button.innerHTML='<div class="spin"></div>';
  if(S.session){
    const{error}=await sb.from('delivery_locations').upsert(loc,{onConflict:'user_id'});
    if(error){console.error('Could not persist delivery address:',error);button.disabled=false;button.textContent='تأكيد وحفظ العنوان';toast('تعذر حفظ العنوان في الحساب. تأكد من تطبيق تحديث قاعدة البيانات.');return}
  }
  S.deliveryLocation=loc;deliveryPendingCoordinates=null;closeModal();toast(S.session?'تم حفظ عنوان التوصيل':'تم تأكيد العنوان لهذا الطلب');
  if(deliveryLocationReturnToAi){deliveryLocationReturnToAi=false;aiOrderDialog()}
  else if(S.page==='account')renderAccountLoggedIn();
  else if(S.page==='checkout')render();
}
async function deleteDeliveryLocation(){
  if(S.session){const{error}=await sb.from('delivery_locations').delete().eq('user_id',S.session.user.id);if(error){toast('تعذر إزالة العنوان');return}}
  S.deliveryLocation=null;deliveryPendingCoordinates=null;deliveryLocationReturnToAi=false;closeModal();toast('تمت إزالة العنوان');if(S.page==='account')renderAccountLoggedIn();else if(S.page==='checkout')render();
}
function openEditProfile(){
  const p=S.profile||{};
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">Edit profile</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">First name</label><input class="finput" id="ep-fname" value="${esc(p.first_name||'')}"></div>
      <div class="fgroup"><label class="flabel">Last name</label><input class="finput" id="ep-lname" value="${esc(p.last_name||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Phone</label><input class="finput" id="ep-phone" value="${esc(p.phone||'')}"></div>
    <button class="btn btn-primary" onclick="saveProfile()">Save changes</button>
  </div></div>`;
}
async function saveProfile(){
  const fname=document.getElementById('ep-fname').value.trim();
  const lname=document.getElementById('ep-lname').value.trim();
  const phone=document.getElementById('ep-phone').value.trim();
  const{error}=await sb.from('profiles').update({first_name:fname,last_name:lname,phone}).eq('id',S.session.user.id);
  if(error){toast('Could not save changes');return}
  S.profile={...S.profile,first_name:fname,last_name:lname,phone};
  closeModal();toast('Profile updated');renderAccountLoggedIn();
}
async function doLogout(){await sb.auth.signOut();if(window.firebase&&firebase.apps.length)await firebase.auth().signOut().catch(()=>{});S.profile=null;S.wishlist=[];S.deliveryLocation=null;toast('Logged out');resetHome()}
