/* AI image attachment: keeps images client-side until the AI request. */
let aiPendingImages=[];
function aiHandleImages(event){
  const files=Array.from(event.target.files||[]).filter(f=>f.type.startsWith('image/')&&f.size<=4*1024*1024).slice(0,4);
  if(!files.length)return;
  Promise.all(files.map(file=>new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve({name:file.name,type:file.type,dataUrl:r.result});r.onerror=reject;r.readAsDataURL(file)}))).then(items=>{
    aiPendingImages=items;toast(`${items.length} image${items.length>1?'s':''} attached`);renderAiBody();
  }).catch(()=>toast('Could not attach the image.'));
}

/* Patch AI call to include attached images without exposing provider keys. */
const _dashOriginalAiCallEdge=window.aiCallEdge;
window.aiCallEdge=async function(text){
  if(!aiPendingImages.length)return _dashOriginalAiCallEdge(text);
  const originalInvoke=sb.functions.invoke.bind(sb.functions);
  // The existing AI function accepts JSON. We temporarily wrap invoke so the original function receives images.
  sb.functions.invoke=async function(name,opts){
    if(name===AI_FUNCTION_NAME && opts?.body){opts={...opts,body:{...opts.body,images:aiPendingImages.map(x=>({type:x.type,dataUrl:x.dataUrl}))}}}
    return originalInvoke(name,opts);
  };
  try{return await _dashOriginalAiCallEdge(text)}finally{sb.functions.invoke=originalInvoke;aiPendingImages=[];const input=document.getElementById('ai-image-input');if(input)input.value='';}
};

