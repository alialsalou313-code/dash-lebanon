/* =========================================================
   AI ASSISTANT (customer-facing widget)
========================================================= */
const AI={sessionId:null,conversationId:null,messages:[],loading:false,open:false};
let aiLastUserMsg='';
function initAiWidget(){
  const pub=S.aiPublic||{};
  const fab=document.getElementById('ai-fab');
  if(!fab)return;
  if(!pub.enabled){fab.classList.add('hide');closeAiPanel();return}
  fab.classList.remove('hide');
  const nameEl=document.getElementById('ai-head-name');if(nameEl)nameEl.textContent=pub.assistant_name||'المساعد الذكي';
  const avEl=document.getElementById('ai-head-avatar');if(avEl)avEl.textContent=(pub.assistant_name||'A').trim()[0].toUpperCase();
  if(!AI.sessionId){AI.sessionId=localStorage.getItem('dl_ai_session');if(!AI.sessionId){AI.sessionId=(crypto.randomUUID?crypto.randomUUID():'sess-'+Date.now()+'-'+Math.random().toString(16).slice(2));localStorage.setItem('dl_ai_session',AI.sessionId)}}
  renderAiBody();
}
function toggleAiPanel(){AI.open?closeAiPanel():openAiPanel()}
function openAiPanel(){AI.open=true;document.getElementById('ai-panel').classList.add('open');document.getElementById('ai-panel-ov').classList.add('open');setTimeout(()=>{const i=document.getElementById('ai-input');if(i)i.focus()},220)}
function closeAiPanel(){AI.open=false;const p=document.getElementById('ai-panel');const o=document.getElementById('ai-panel-ov');if(p)p.classList.remove('open');if(o)o.classList.remove('open')}
function aiNewConversation(){AI.conversationId=null;AI.messages=[];renderAiBody();toast('تم بدء محادثة جديدة')}
function aiAutoGrow(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,90)+'px'}
function aiInputKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();aiSend()}}
function aiQuick(text){const i=document.getElementById('ai-input');i.value=text;aiSend()}
function aiCleanSpeech(text){return String(text||'').replace(/[\p{Extended_Pictographic}]/gu,' ').replace(/[_*`#~\-–—•|<>[\]{}()]/g,' ').replace(/\s+/g,' ').trim()}
function aiSpeak(index){const m=AI.messages[index];if(!m||!window.speechSynthesis)return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(aiCleanSpeech(m.content));u.lang=/[\u0600-\u06FF]/.test(u.text)?'ar-LB':'en-US';window.speechSynthesis.speak(u)}
function aiVoiceInput(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){toast('التحويل الصوتي غير مدعوم في هذا المتصفح');return}
 const r=new SR();r.lang='ar-LB';r.interimResults=false;r.maxAlternatives=3;
 r.onstart=()=>toast('تحدث الآن…');r.onresult=e=>{const best=[...e.results[0]].sort((a,b)=>b.confidence-a.confidence)[0];const input=document.getElementById('ai-input');input.value=best.transcript;aiAutoGrow(input)};
 r.onerror=()=>toast('تعذر تحويل الصوت إلى نص');r.start();
}
function aiProductCard(pid){
 const p=S.products.find(x=>x.id===pid);if(!p)return'';
 const productImage=p.cover_image||(p.product_images&&p.product_images[0]&&p.product_images[0].url)||'';
 const hasPrice=p.price!==null&&p.price!==undefined&&p.price!==''&&Number.isFinite(Number(p.price));
 const hasOldPrice=p.compare_at_price!==null&&p.compare_at_price!==undefined&&p.compare_at_price!==''&&Number.isFinite(Number(p.compare_at_price));
 const oldPrice=hasOldPrice?Number(p.compare_at_price):null,currentPrice=hasPrice?Number(p.price):null,hasDiscount=hasPrice&&hasOldPrice&&oldPrice>currentPrice,discount=hasDiscount?discPct(oldPrice,currentPrice):0;
 const available=p.is_active===true;
 return `<article class="ai-product">
   ${productImage?`<img src="${esc(productImage)}" alt="${esc(p.name||'صورة المنتج')}" loading="lazy">`:`<div class="ai-product-noimage">لا توجد صورة متاحة</div>`}
   <div class="ai-product-name">${esc(p.name)}</div>
   ${p.description?`<div class="ai-product-desc">${esc(p.description)}</div>`:''}
   ${hasPrice?`<div class="ai-product-price"><span class="ai-product-current">${fmt(p.price)}</span>${hasDiscount?`<del class="ai-product-old">${fmt(oldPrice)}</del>${discount>0?`<span class="ai-product-discount">-${discount}%</span>`:''}`:''}</div>`:''}
   <div class="ai-product-stock ${available?'':'unavailable'}">${available?'● متوفر':'● غير متوفر'}</div>
   ${available&&hasPrice?`<button class="btn btn-primary btn-sm" onclick="quickAdd('${esc(p.id)}');renderAiBody()">أضف إلى السلة</button>`:''}
 </article>`;
}
function aiCartSummary(){return S.cart.map(i=>`${i.name} × ${i.qty} = ${fmt(i.price*i.qty)}`).join('\n')||'السلة فارغة'}
async function aiCreateOrderFromChat(info){
 if(!S.cart.length)throw new Error('السلة فارغة');
 if(!S.deliveryLocation?.confirmed_at)throw new Error('delivery_location_required');
 const orderNumber='DL-'+Date.now().toString().slice(-7),subtotal=cartSub(),delivery=4,total=parseFloat((subtotal+delivery).toFixed(2)),earn=calcEarnPts(total);
 const row={order_number:orderNumber,user_id:S.session?S.session.user.id:null,status:'confirmed',full_name:info.full_name,phone:info.phone,phone2:info.phone2||'',city:info.city||'',district:info.district||'',full_address:info.address,floor:'',notes:'',subtotal,delivery_fee:delivery,discount_amount:0,coupon_code:null,total,points_earned:earn};
 const {data:order,error}=await sb.from('orders').insert(row).select().single(); if(error)throw error;
 const items=S.cart.map(i=>({order_id:order.id,product_id:i.product_id,product_name:i.name,unit_price:i.price,quantity:i.qty,is_bundle:i.is_bundle,bundle_label:i.bundle_label}));
 const ir=await sb.from('order_items').insert(items);if(ir.error)throw ir.error;
 S.cart=[];saveCart();updateCartBadge();
 return {orderNumber,total:row.total,subtotal:row.subtotal,delivery:row.delivery_fee,items,info};
}
async function aiOrderDialog(){
 if(!S.cart.length){toast('السلة فارغة');return}
 if(!S.deliveryLocation?.confirmed_at){toast('أضف عنوان التوصيل وأكّده أولاً');openDeliveryLocationEditor(true);return}
 const loc=S.deliveryLocation;
 document.getElementById('modal-root').innerHTML=`<div class="modal-ov"><div class="modal-sheet"><div class="modal-title">تأكيد بيانات الطلب</div>
 <div class="fgroup"><label class="flabel">الاسم الكامل *</label><input class="finput" id="ai-o-name" value="${esc(S.profile?`${S.profile.first_name||''} ${S.profile.last_name||''}`.trim():'')}"></div><div class="fgroup"><label class="flabel">رقم الهاتف *</label><input class="finput" id="ai-o-phone" value="${esc(S.profile?.phone||'')}"></div><div class="fgroup"><label class="flabel">رقم هاتف ثانٍ</label><input class="finput" id="ai-o-phone2"></div>
 <div class="delivery-location-card"><strong>📍 عنوان التوصيل</strong><div class="fgroup" style="margin-top:9px"><label class="flabel">المحافظة / المدينة *</label><input class="finput" id="ai-o-city" value="${esc(loc.city||'')}"></div><div class="fgroup"><label class="flabel">المنطقة / الحي</label><input class="finput" id="ai-o-district" value="${esc(loc.district||'')}"></div><div class="fgroup"><label class="flabel">العنوان التفصيلي *</label><textarea class="ftextarea" id="ai-o-address">${esc(loc.full_address||'')}</textarea></div><button class="btn btn-ghost btn-sm" onclick="closeModal();openDeliveryLocationEditor(true)">تعديل العنوان المحفوظ</button></div>
 <div class="summary-row"><span>إجمالي المنتجات</span><span>${fmt(cartSub())}</span></div><div class="summary-row"><span>رسوم التوصيل الثابتة</span><span>$4.00</span></div><div class="summary-row total"><span>المجموع النهائي</span><span>${fmt(cartSub()+4)}</span></div>
 <button class="btn btn-primary" onclick="aiConfirmOrder()">تأكيد الطلب</button><button class="btn btn-ghost" onclick="closeModal()">إلغاء</button></div></div>`;
}
async function aiConfirmOrder(){
 const info={full_name:document.getElementById('ai-o-name').value.trim(),phone:document.getElementById('ai-o-phone').value.trim(),phone2:document.getElementById('ai-o-phone2').value.trim(),city:document.getElementById('ai-o-city').value.trim(),district:document.getElementById('ai-o-district').value.trim(),address:document.getElementById('ai-o-address').value.trim()};
 if(!info.full_name||!info.phone||!info.city||!info.address){toast('يرجى تعبئة الحقول المطلوبة');return}
 if(!S.deliveryLocation?.confirmed_at){toast('أكّد عنوان التوصيل قبل الطلب');return}
 try{const o=await aiCreateOrderFromChat(info);closeModal();AI.messages.push({role:'assistant',content:`تم إتمام طلبك بنجاح.\n\nرقم الطلب: ${o.orderNumber}\nالاسم: ${o.info.full_name}\nالهاتف: ${o.info.phone}${o.info.phone2?`\nالهاتف الثاني: ${o.info.phone2}`:''}\nعنوان التوصيل: ${o.info.city}${o.info.district?`، ${o.info.district}`:''} — ${o.info.address}\n\nالمنتجات:\n${o.items.map((x,i)=>`${i+1}. ${x.product_name}\nالكمية: ${x.quantity}\nالسعر: ${fmt(x.unit_price)}`).join('\n')}\n\nإجمالي المنتجات: ${fmt(o.subtotal)}\nرسوم التوصيل الثابتة: ${fmt(o.delivery)}\nالمجموع النهائي: ${fmt(o.total)}\n\nتم إرسال طلبك بنجاح.`});renderAiBody();nav('orders',null,false)}catch(e){console.error(e);toast('تعذر إنشاء الطلب')}
}

function renderAiBody(){
  const body=document.getElementById('ai-body');if(!body)return;
  if(!AI.messages.length){
    const pub=S.aiPublic||{};
    body.innerHTML=`<div class="ai-empty"><div class="ai-empty-ico">✨</div><div style="font-weight:700;color:var(--text);margin-bottom:4px">${esc(pub.assistant_name||'المساعد الذكي')}</div><div style="font-size:.83rem">${esc(pub.welcome_message||'اسألني أي شيء عن المتجر.')}</div>
    <div class="ai-suggest">
      <button onclick="aiQuick('ما المنتجات أو العروض المتوفرة حاليًا؟')">العروض الحالية</button>
      <button onclick="aiQuick('كيف يمكنني تتبع طلبي؟')">تتبع طلبي</button>
      <button onclick="aiQuick('ما سياسة التوصيل والإلغاء لديكم؟')">التوصيل والإلغاء</button>
    </div></div>`;
    return;
  }
  body.innerHTML=AI.messages.map((m,idx)=>{
    if(m.role==='user')return `<div class="ai-msg user">${esc(m.content)}</div>`;
    if(m.role==='error')return `<div class="ai-msg error">${esc(m.content)}<br><button class="ai-retry" onclick="aiRetry()">إعادة المحاولة</button></div>`;
    const cards=(m.products||[]).map(aiProductCard).join('');
    const orderBtn=m.offerOrder?`<button class="btn btn-primary btn-sm" onclick="aiOrderDialog()">متابعة الطلب</button>`:'';
    return `<div class="ai-msg assistant">${mdLite(m.content)}${cards}${orderBtn}<div class="ai-msg-actions"><button class="ai-speak" onclick="aiSpeak(${idx})" title="قراءة الرسالة">🔊 قراءة</button></div></div>`;
  }).join('')+(AI.loading?`<div class="ai-typing"><span></span><span></span><span></span></div>`:'');
  body.scrollTop=body.scrollHeight;
}
async function aiSend(){
  const input=document.getElementById('ai-input');
  const text=input.value.trim();
  if(!text||AI.loading)return;
  aiLastUserMsg=text;
  AI.messages.push({role:'user',content:text});
  input.value='';aiAutoGrow(input);
  AI.loading=true;document.getElementById('ai-send').disabled=true;
  renderAiBody();
  await aiCallEdge(text);
}
async function aiRetry(){
  AI.messages=AI.messages.filter(m=>m.role!=='error');
  AI.loading=true;renderAiBody();
  await aiCallEdge(aiLastUserMsg);
}
async function aiCallEdge(text){
  try{

    const { data, error } = await sb.functions.invoke(
      AI_FUNCTION_NAME,
      {
        body: {
          message: text,
          conversationId: AI.conversationId,
          sessionId: AI.sessionId,
          model: "openai/gpt-oss-20b",
          clientContext: {
            products: S.products.map(p=>({id:p.id,name:p.name,price:p.price,compare_at_price:p.compare_at_price,description:p.description,is_active:p.is_active,image:coverImg(p)})),
            cart: S.cart.map(i=>({product_id:i.product_id,name:i.name,qty:i.qty,price:i.price})),
            cartTotals: {subtotal:cartSub(),delivery:cartDelivery(),total:cartTotal()},
            deliveryLocation: S.deliveryLocation&&S.deliveryLocation.confirmed_at?{confirmed:true,city:S.deliveryLocation.city,district:S.deliveryLocation.district||'',full_address:S.deliveryLocation.full_address}:null
          }
        }
      }
    );

    AI.loading = false;

    if(error || !data || data.error){

      console.error("AI Edge Function Error:", error, data);

      AI.messages.push({
        role: 'error',
        content:
          data?.error ||
          data?.message ||
          error?.message ||
          'عذرًا، المساعد الذكي غير متاح حاليًا. يرجى المحاولة لاحقًا.'
      });

    }else{

      console.log("AI Response:", data);

      AI.conversationId =
        data.conversationId ||
        AI.conversationId;

      const reply =
        data.reply ||
        data.message ||
        data.response ||
        data.content ||
        data?.data?.choices?.[0]?.message?.content ||
        'عذرًا، لم أتمكن من إنشاء رد.';

      AI.messages.push({
        role: 'assistant',
        content: reply,
        products: Array.isArray(data.productIds)?data.productIds:[],
        offerOrder: !!data.offerOrder
      });

    }

  }catch(err){

    console.error("AI Unexpected Error:", err);

    AI.loading = false;

    AI.messages.push({
      role: 'error',
      content:
        'عذرًا، المساعد الذكي غير متاح حاليًا. يرجى المحاولة لاحقًا.'
    });

  }

  document.getElementById('ai-send').disabled = false;

  renderAiBody();
}

/* ---- tiny markdown renderer for AI replies: headers, bold/italic, code,
        bullet/numbered lists, and pipe tables → real <table> markup ---- */
function mdLite(raw){
  if(!raw)return'';
  const lines=String(raw).replace(/\r\n/g,'\n').split('\n');
  let html='';let i=0;const n=lines.length;
  const inline=s=>esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*]+)\*/g,'$1<em>$2</em>');
  const isTableRow=l=>/^\s*\|.*\|\s*$/.test(l);
  while(i<n){
    const line=lines[i];
    if(/^```/.test(line)){
      const code=[];i++;
      while(i<n&&!/^```/.test(lines[i])){code.push(lines[i]);i++}
      i++;html+=`<pre><code>${esc(code.join('\n'))}</code></pre>`;continue;
    }
    if(isTableRow(line)){
      const rows=[];while(i<n&&isTableRow(lines[i])){rows.push(lines[i]);i++}
      if(rows.length>=2){
        const parseRow=r=>r.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(c=>c.trim());
        const header=parseRow(rows[0]);
        const sepLine=/^[\s:|-]+$/.test(rows[1]);
        const bodyRows=(sepLine?rows.slice(2):rows.slice(1)).map(parseRow);
        html+=`<div class="ai-table-wrap"><table class="ai-table"><thead><tr>${header.map(h=>`<th>${inline(h)}</th>`).join('')}</tr></thead><tbody>${bodyRows.map(r=>`<tr>${r.map(c=>`<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      }else{html+=`<p>${inline(rows.join(' '))}</p>`}
      continue;
    }
    if(/^#{1,3}\s+/.test(line)){
      const lvl=Math.min(line.match(/^#+/)[0].length+1,3);
      html+=`<h${lvl}>${inline(line.replace(/^#{1,3}\s+/,''))}</h${lvl}>`;i++;continue;
    }
    if(/^\s*[-*]\s+/.test(line)){
      const items=[];while(i<n&&/^\s*[-*]\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*[-*]\s+/,''));i++}
      html+=`<ul>${items.map(it=>`<li>${inline(it)}</li>`).join('')}</ul>`;continue;
    }
    if(/^\s*\d+\.\s+/.test(line)){
      const items=[];while(i<n&&/^\s*\d+\.\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*\d+\.\s+/,''));i++}
      html+=`<ol>${items.map(it=>`<li>${inline(it)}</li>`).join('')}</ol>`;continue;
    }
    if(line.trim()===''){i++;continue}
    const para=[line];i++;
    while(i<n&&lines[i].trim()!==''&&!/^(#{1,3}\s|```|\s*[-*]\s|\s*\d+\.\s)/.test(lines[i])&&!isTableRow(lines[i])){para.push(lines[i]);i++}
    html+=`<p>${para.map(inline).join('<br>')}</p>`;
  }
  return html;
}
