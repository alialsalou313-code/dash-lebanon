/* =========================================================
   CONFIG
========================================================= */
const SUPABASE_URL='https://xlsvxyytwbakvvreyoar.supabase.co';
const DELIVERY_REVERSE_GEOCODING_READY=false; // Enable only after GEOAPIFY_API_KEY is set as a Supabase secret.
const SUPABASE_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhsc3Z4eXl0d2Jha3Z2cmV5b2FyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzMTk3NzYsImV4cCI6MjEwNDg5NTc3Nn0.9HOaTZUeJqBje79PCZo3O-sfQIiPGZi223i4fJLcSZo';
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
const AI_FUNCTION_NAME='ai-chat';
const ADMIN_BOOTSTRAP_EMAIL=''; // Admin email must be configured in the admin/profile system, not hardcoded in HTML. // Supabase Edge Function name (see /supabase/functions/ai-chat)
