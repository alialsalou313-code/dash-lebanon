/* =========================================================
   PRODUCT HELPERS
========================================================= */
function discPct(oldP,p){if(!oldP||oldP<=p)return 0;return Math.round((1-p/oldP)*100)}
function coverImg(p){return p.cover_image||(p.product_images&&p.product_images[0]&&p.product_images[0].url)||'https://placehold.co/400x400/e7ebf3/98a2b8?text=No+Image'}
function isWished(id){return S.wishlist.includes(id)}
function calcEarnPts(total){return Math.round(total*(S.settings.points_per_dollar||7))}

async function toggleWish(id,ev){
  if(ev)ev.stopPropagation();
  if(!S.session){toast('Log in to save favorites');nav('account');return}
  const uid=S.session.user.id;
  if(isWished(id)){
    await sb.from('wishlists').delete().eq('user_id',uid).eq('product_id',id);
    S.wishlist=S.wishlist.filter(x=>x!==id);
  }else{
    await sb.from('wishlists').insert({user_id:uid,product_id:id});
    S.wishlist.push(id);
  }
  document.querySelectorAll(`.wish-btn[data-pid="${id}"]`).forEach(b=>b.classList.toggle('active',isWished(id)));
}
function quickAdd(pid,ev){
  if(ev)ev.stopPropagation();
  const p=S.products.find(x=>x.id===pid);if(!p||p.is_active!==true)return;
  const uid=p.id+'_single';
  const ex=S.cart.find(i=>i._uid===uid);
  if(ex)ex.qty+=1;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:p.price,qty:1,delivery_price:p.delivery_price,is_bundle:false,bundle_label:''});
  saveCart();updateCartBadge();toast('Added to cart');
}
