/* =========================================================
   PRODUCT DETAIL
========================================================= */
let pdImages=[];let pdIdx=0;let pdReviews=[];
async function pProduct(){
  const p=S.products.find(x=>x.id===S.data);
  if(!p){nav('home');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const[{data:imgs},{data:reviews}]=await Promise.all([
    sb.from('product_images').select('*').eq('product_id',p.id).order('sort_order'),
    sb.from('reviews').select('*, profiles(first_name,last_name)').eq('product_id',p.id).eq('status','approved').order('created_at',{ascending:false})
  ]);
  pdImages=(imgs&&imgs.length)?imgs.map(i=>i.url):[coverImg(p)];
  // make sure the designated cover image (if set) appears first in the gallery
  if(p.cover_image){
    const ci=pdImages.indexOf(p.cover_image);
    if(ci>0){pdImages.splice(ci,1);pdImages.unshift(p.cover_image)}
    else if(ci===-1){pdImages.unshift(p.cover_image)}
  }
  pdIdx=0;pdReviews=reviews||[];
  renderProductPage(p);
}
function renderProductPage(p){
  const disc=discPct(p.compare_at_price,p.price);
  const wished=isWished(p.id);
  const earn=calcEarnPts(S.buyMode==='bundle'&&p.bundle_qty?p.bundle_price:p.price*S.dqty);
  let bundleSec='';
  if(p.bundle_qty){
    const savings=fmt(p.price*p.bundle_qty-p.bundle_price);
    bundleSec=`<div class="bundle-opts">
      <div class="bopt ${S.buyMode==='normal'?'on':''}" onclick="selMode('normal')"><div style="font-weight:700;font-size:.85rem">Single item</div><div style="color:var(--primary);font-weight:800;margin-top:4px;font-family:var(--font-m)">${fmt(p.price)}</div></div>
      <div class="bopt ${S.buyMode==='bundle'?'on':''}" onclick="selMode('bundle')"><div class="bopt-badge">Best value</div><div style="font-weight:700;font-size:.85rem">${p.bundle_qty} pack</div><div style="color:var(--primary);font-weight:800;margin-top:4px;font-family:var(--font-m)">${fmt(p.bundle_price)}</div><div style="color:var(--success);font-size:.72rem;font-weight:700;font-family:var(--font-m)">Save ${savings}</div></div>
    </div>`;
  }
  const specs=(p.specifications||[]).length?`<table class="spec-table">${p.specifications.map(s=>`<tr><td>${esc(s.label)}</td><td>${esc(s.value)}</td></tr>`).join('')}</table>`:'';
  const showQty=!p.bundle_qty||S.buyMode==='normal';
  const others=S.products.filter(x=>x.id!==p.id).slice(0,4);
  const revAvg=p.rating_count?`<span class="stars">★★★★★</span> ${p.rating_avg} · ${p.rating_count} review${p.rating_count>1?'s':''}`:'No reviews yet';
  const revList=pdReviews.length?pdReviews.map(r=>`<div class="review-item"><div class="review-head"><div class="review-avatar">${esc((r.profiles?.first_name||'U')[0])}</div><div><div class="review-name">${esc(r.profiles?.first_name||'Customer')} ${esc(r.profiles?.last_name||'')}</div><div class="review-date">${new Date(r.created_at).toLocaleDateString()} · ${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div></div></div><div class="review-text">${esc(r.comment)}</div></div>`).join(''):`<div style="color:var(--muted);font-size:.88rem;padding:10px 0">No reviews yet — be the first to share your experience.</div>`;
  const hasMulti=pdImages.length>1;
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="pd-wrap">
      <div>
        <div class="pd-gallery-main" id="pd-gallery">
          ${hasMulti?`<button class="pd-arrow prev" onclick="pdPrev()" aria-label="Previous image">‹</button><button class="pd-arrow next" onclick="pdNext()" aria-label="Next image">›</button>`:''}
          <img id="pd-main-img" src="${esc(pdImages[0])}" onerror="this.src='https://placehold.co/500x500/e7ebf3/98a2b8?text=No+Image'">
          ${hasMulti?`<div class="pd-dots" id="pd-dots">${pdImages.map((_,i)=>`<span class="${i===0?'on':''}"></span>`).join('')}</div>`:''}
        </div>
        ${hasMulti?`<div class="pd-thumbs">${pdImages.map((im,i)=>`<div class="pd-thumb ${i===0?'on':''}" onclick="pdSwap(${i})"><img src="${esc(im)}"></div>`).join('')}</div>`:''}
      </div>
      <div>
        <div class="pd-name">${esc(p.name)}</div>
        <div class="pd-rating">${revAvg}</div>
        ${p.compare_at_price?`<div class="pd-price-row"><span class="pd-old">${fmt(p.compare_at_price)}</span>${disc>0?`<span class="status-badge st-cancelled">-${disc}%</span>`:''}</div>`:''}
        <div class="pd-price-row"><span class="pd-price" id="pd-price">${S.buyMode==='bundle'?fmt(p.bundle_price):fmt(p.price)}</span></div>
        <div class="pd-lbp" id="pd-lbp">${fmtLBP(S.buyMode==='bundle'?p.bundle_price:p.price)} · Delivery $4.00</div>
        <div class="pd-desc">${esc(p.description||'')}</div>
        ${specs}
        ${bundleSec}
        <div class="pts-chip" id="pts-chip">★ Earn <strong>${earn}</strong> points with this order</div>
        <div class="qty-row" id="qty-row" style="${!showQty?'display:none':''}">
          <span style="font-weight:700;font-size:.88rem">Quantity</span>
          <div class="qty-ctrl"><button class="qbtn" onclick="pdQty(-1)">−</button><input class="qty-val" id="pd-qty" value="${S.dqty}" oninput="pdQtyManual(this.value)"><button class="qbtn" onclick="pdQty(1)">+</button></div>
        </div>
        <div class="pd-actions">
          <button class="btn btn-primary" onclick="addToCart('${p.id}')">Add to cart</button>
          <button class="icon-btn btn-icon-only wish-btn ${wished?'active':''}" data-pid="${p.id}" onclick="toggleWish('${p.id}',event);this.classList.toggle('active')" style="height:48px">${wished?'♥':'♡'}</button>
        </div>
      </div>
    </div>

    <div class="card" style="padding:20px;margin-top:26px">
      <div class="section-head"><div class="section-title" style="font-size:1.08rem">Customer reviews</div>${S.session?`<button class="btn btn-ghost btn-sm" onclick="openReviewModal('${p.id}')">Write a review</button>`:''}</div>
      ${revList}
    </div>

    ${others.length?`<div style="margin-top:26px"><div class="section-title" style="font-size:1.08rem;margin-bottom:12px">You might also like</div><div class="grid">${others.map(x=>productCardHTML(x)).join('')}</div></div>`:''}
  </div>`;
  if(hasMulti)bindGallerySwipe();
}
function pdSwap(i){
  pdIdx=i;
  const img=document.getElementById('pd-main-img');
  img.style.opacity='0';
  setTimeout(()=>{img.src=pdImages[i];img.style.opacity='1'},90);
  document.querySelectorAll('.pd-thumb').forEach((t,x)=>t.classList.toggle('on',x===i));
  const dots=document.getElementById('pd-dots');
  if(dots)dots.querySelectorAll('span').forEach((d,x)=>d.classList.toggle('on',x===i));
}
function pdNext(){pdSwap((pdIdx+1)%pdImages.length)}
function pdPrev(){pdSwap((pdIdx-1+pdImages.length)%pdImages.length)}
function bindGallerySwipe(){
  const el=document.getElementById('pd-gallery');
  if(!el)return;
  let startX=0,startY=0,dragging=false;
  el.addEventListener('touchstart',e=>{startX=e.touches[0].clientX;startY=e.touches[0].clientY;dragging=true},{passive:true});
  el.addEventListener('touchmove',e=>{ if(!dragging)return; },{passive:true});
  el.addEventListener('touchend',e=>{
    if(!dragging)return;dragging=false;
    const dx=e.changedTouches[0].clientX-startX;
    const dy=e.changedTouches[0].clientY-startY;
    if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)){
      if(dx<0)pdNext();else pdPrev();
    }
  });
  const img=document.getElementById('pd-main-img');
  if(img)img.style.transition='opacity .15s';
}
function selMode(mode){
  S.buyMode=mode;const p=S.products.find(x=>x.id===S.data);
  document.querySelectorAll('.bopt').forEach((b,i)=>b.classList.toggle('on',(i===0&&mode==='normal')||(i===1&&mode==='bundle')));
  document.getElementById('qty-row').style.display=mode==='bundle'?'none':'flex';
  document.getElementById('pd-price').textContent=mode==='bundle'?fmt(p.bundle_price):fmt(p.price);
  document.getElementById('pd-lbp').textContent=`${fmtLBP(mode==='bundle'?p.bundle_price:p.price)} · Delivery $4.00`;
  const earn=calcEarnPts(mode==='bundle'?p.bundle_price:p.price*S.dqty);
  document.getElementById('pts-chip').innerHTML=`★ Earn <strong>${earn}</strong> points with this order`;
}
function pdQty(d){const p=S.products.find(x=>x.id===S.data);S.dqty=Math.max(1,S.dqty+d);document.getElementById('pd-qty').value=S.dqty;const earn=calcEarnPts(p.price*S.dqty);document.getElementById('pts-chip').innerHTML=`★ Earn <strong>${earn}</strong> points with this order`}
function pdQtyManual(v){S.dqty=Math.max(1,parseInt(v)||1)}
function addToCart(pid){
  const p=S.products.find(x=>x.id===pid);if(!p)return;
  if(S.buyMode==='bundle'&&p.bundle_qty){
    const uid=p.id+'_bundle';
    const unitPrice=parseFloat((p.bundle_price/p.bundle_qty).toFixed(2));
    const ex=S.cart.find(i=>i._uid===uid);
    if(ex)ex.qty+=p.bundle_qty;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:unitPrice,qty:p.bundle_qty,delivery_price:p.delivery_price,is_bundle:true,bundle_label:`${p.bundle_qty}-pack`});
  }else{
    const uid=p.id+'_single';
    const ex=S.cart.find(i=>i._uid===uid);
    if(ex)ex.qty+=S.dqty;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:p.price,qty:S.dqty,delivery_price:p.delivery_price,is_bundle:false,bundle_label:''});
  }
  saveCart();updateCartBadge();toast('Added to cart');
}
