/* =========================================================
   CART
========================================================= */
function pCart(){
  if(!S.cart.length)return `<div class="page">
    <button class="back-link" onclick="goBack()">← Continue shopping</button>
    <div class="empty-box"><div class="empty-ico">🛒</div><div class="empty-ttl">Your cart is empty</div><div class="empty-sub">Add products to get started.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div>
  </div>`;
  const earn=calcEarnPts(cartTotal());
  const rows=S.cart.map(i=>`<div class="ci-row">
    <img src="${esc(i.image)}" onerror="this.src='https://placehold.co/76x76/e7ebf3/98a2b8?text=?'">
    <div class="ci-body">
      <div class="ci-name">${esc(i.name)}</div>
      <div class="ci-meta">${i.is_bundle?i.bundle_label+' · ':''}${fmt(i.price)} each</div>
      <div class="ci-ctrls">
        <button class="mini-btn" onclick="cartQty('${i._uid}',${i.qty-1})">−</button>
        <span style="font-weight:700;min-width:20px;text-align:center;font-family:var(--font-m)">${i.qty}</span>
        <button class="mini-btn" onclick="cartQty('${i._uid}',${i.qty+1})">+</button>
        <span class="ci-sub">${fmt(i.price*i.qty)}</span>
      </div>
    </div>
    <button class="ci-rm" onclick="cartRemove('${i._uid}')">✕</button>
  </div>`).join('');
  return `<div class="page" style="padding-bottom:110px">
    <button class="back-link" onclick="goBack()">← Continue shopping</button>
    ${rows}
    <div class="card" style="padding:15px 18px;display:flex;align-items:center;gap:11px;margin-bottom:14px;background:rgba(245,166,35,.06);border-color:rgba(245,166,35,.3)">
      <div style="font-size:1.35rem">★</div><div style="flex:1"><strong style="font-size:.88rem">You'll earn ${earn} points</strong><div style="font-size:.76rem;color:var(--muted)">from this order</div></div>
    </div>
    <div class="card" style="padding:18px">
      <div class="summary-row"><span>Subtotal</span><span>${fmt(cartSub())}</span></div>
      <div class="summary-row"><span>Delivery</span><span>${fmt(cartDelivery())}</span></div>
      <div class="summary-row total"><span>Total</span><span>${fmt(cartTotal())}</span></div>
    </div>
  </div>
  <div class="sticky-bar"><div class="sticky-bar-in"><button class="btn btn-primary" onclick="nav('checkout')">Checkout — ${fmt(cartTotal())}</button></div></div>`;
}
function cartQty(uid,q){if(q<1){cartRemove(uid);return}const i=S.cart.find(x=>x._uid===uid);if(i)i.qty=q;saveCart();render();updateCartBadge()}
function cartRemove(uid){S.cart=S.cart.filter(x=>x._uid!==uid);saveCart();render();updateCartBadge()}
