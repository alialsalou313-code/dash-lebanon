/* =========================================================
   CONTACT
========================================================= */
function pContact(){
  const st=S.settings;
  return `<div class="page" style="max-width:560px">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="hero" style="padding:28px 22px"><div class="hero-in"><div class="hero-eyebrow">We usually reply within the hour</div><h1 style="font-size:1.5rem">Contact us</h1><p>We're here to help with anything you need.</p></div></div>
    <div class="card form-card">
      <div id="ct-msg"></div>
      <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="ct-name"></div>
      <div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="ct-phone"></div>
      <div class="fgroup"><label class="flabel">Message <span class="req">*</span></label><textarea class="ftextarea" id="ct-msg-txt"></textarea></div>
      <button class="btn btn-primary" id="ct-btn" onclick="sendContact()">Send message</button>
    </div>
    <div class="card" style="padding:18px;text-align:center">
      <div class="footer-h">Follow us</div>
      <div class="soc-row" style="justify-content:center">
        ${st.instagram_url?`<a href="${esc(st.instagram_url)}" target="_blank">IG</a>`:''}
        ${st.facebook_url?`<a href="${esc(st.facebook_url)}" target="_blank">FB</a>`:''}
        ${st.tiktok_url?`<a href="${esc(st.tiktok_url)}" target="_blank">TT</a>`:''}
        <a href="https://wa.me/${(st.whatsapp_number||'').replace(/\D/g,'')}" target="_blank">WA</a>
      </div>
    </div>
  </div>`;
}
async function sendContact(){
  const name=document.getElementById('ct-name').value.trim();
  const phone=document.getElementById('ct-phone').value.trim();
  const msg=document.getElementById('ct-msg-txt').value.trim();
  if(!name||!phone||!msg){toast('Please fill in all fields');return}
  const btn=document.getElementById('ct-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  const{error}=await sb.from('contact_messages').insert({name,phone,message:msg});
  btn.disabled=false;btn.textContent='Send message';
  if(error){document.getElementById('ct-msg').innerHTML='<div class="alert alert-err">Could not send — please try again.</div>';return}
  document.getElementById('ct-msg').innerHTML=`<div class="alert alert-ok">Message sent — we'll get back to you soon.</div>`;
  document.getElementById('ct-name').value='';document.getElementById('ct-phone').value='';document.getElementById('ct-msg-txt').value='';
}
