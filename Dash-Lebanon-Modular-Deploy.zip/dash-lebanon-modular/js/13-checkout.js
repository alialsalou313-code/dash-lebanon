/* =========================================================
   CHECKOUT
========================================================= */
function pCheckout(){
  const prof=S.profile;
  const loc=S.deliveryLocation||{};
  return `<div class="page" style="padding-bottom:104px">
    <button class="back-link" onclick="goBack()">← Back to cart</button>
    <div class="card form-card">
      <div class="form-title">Contact information</div>
      <div class="fgroup"><label class="flabel">Full name <span class="req">*</span></label><input class="finput" id="co-name" value="${esc(prof?(prof.first_name+' '+prof.last_name):'')}"></div>
      <div class="frow2">
        <div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="co-phone" value="${esc(prof?.phone||'')}"></div>
        <div class="fgroup"><label class="flabel">Second phone</label><input class="finput" id="co-phone2"></div>
      </div>
    </div>
    <div class="card form-card">
      <div class="form-title">📍 Delivery location</div>
      <div class="delivery-location-card" style="margin-bottom:0">
        ${loc.confirmed_at?`<strong>${esc(loc.city||'')}${loc.district?` · ${esc(loc.district)}`:''}</strong><div style="font-size:.84rem;color:var(--muted);margin-top:4px">${esc(loc.full_address||'')}</div>`:`<div style="font-size:.84rem;color:var(--muted)">Add the delivery address for this order. You can enter it manually.</div>`}
        <div class="delivery-location-actions"><button class="btn btn-ghost btn-sm" onclick="openDeliveryLocationEditor()">${loc.confirmed_at?'Edit saved address':'Add delivery address'}</button></div>
      </div>
      <div class="muted-note" style="margin-top:9px">Delivery is a fixed $4.00 anywhere in Lebanon.</div>
    </div>
    <div class="card form-card">
      <div class="form-title">Delivery address</div>
      <div class="frow2">
        <div class="fgroup"><label class="flabel">City <span class="req">*</span></label><input class="finput" id="co-city" value="${esc(loc.city||'')}"></div>
        <div class="fgroup"><label class="flabel">District / area</label><input class="finput" id="co-district" value="${esc(loc.district||'')}"></div>
      </div>
      <div class="fgroup"><label class="flabel">Full address <span class="req">*</span></label><input class="finput" id="co-address" value="${esc(loc.full_address||'')}"></div>
      <div class="fgroup"><label class="flabel">Floor</label><input class="finput" id="co-floor"></div>
      <div class="fgroup"><label class="flabel">Notes</label><textarea class="ftextarea" id="co-notes"></textarea></div>
    </div>
    <div class="card form-card">
      <div class="form-title">Coupon code</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><input class="finput" id="co-coupon" placeholder="Enter code" style="flex:1;min-width:140px"><button class="btn btn-ghost" style="width:auto;padding:12px 18px" onclick="applyCoupon()">Apply</button></div>
      <div id="coupon-msg" style="font-size:.8rem;margin-top:8px;font-family:var(--font-m)"></div>
    </div>
  </div>
  <div class="sticky-bar"><div class="sticky-bar-in"><button class="btn btn-primary" id="place-order-btn" onclick="placeOrder()">Place order — ${fmt(cartTotal())}</button></div></div>`;
}
S.appliedDiscount=0;S.appliedCoupon=null;
async function applyCoupon(){
  const code=document.getElementById('co-coupon').value.trim().toUpperCase();
  const msg=document.getElementById('coupon-msg');
  if(!code){msg.textContent='';return}
  const{data,error}=await sb.from('coupons').select('*').eq('code',code).eq('is_active',true).maybeSingle();
  if(error||!data){msg.textContent='Invalid or expired code';msg.style.color='var(--danger)';return}
  if(data.expires_at&&new Date(data.expires_at)<new Date()){msg.textContent='This coupon has expired';msg.style.color='var(--danger)';return}
  if(data.max_uses&&data.used_count>=data.max_uses){msg.textContent='This coupon has reached its usage limit';msg.style.color='var(--danger)';return}
  S.appliedDiscount=data.discount_type==='percent'?parseFloat((cartSub()*data.discount_value/100).toFixed(2)):data.discount_value;
  S.appliedCoupon=data;
  msg.textContent=`Applied! You save ${fmt(S.appliedDiscount)}`;msg.style.color='var(--success)';
  document.getElementById('place-order-btn').textContent=`Place order — ${fmt(cartTotal())}`;
}
async function placeOrder(){
  const fields=[['co-name','name'],['co-phone','phone'],['co-city','city'],['co-address','address']];
  const info={};let ok=true;
  fields.forEach(([id,key])=>{const el=document.getElementById(id);const v=el.value.trim();if(!v){el.classList.add('inv');ok=false}else{el.classList.remove('inv');info[key]=v}});
  if(!ok){toast('Please fill in all required fields');return}
  info.district=document.getElementById('co-district').value.trim();
  info.phone2=document.getElementById('co-phone2').value.trim();
  info.floor=document.getElementById('co-floor').value.trim();
  info.notes=document.getElementById('co-notes').value.trim();
  const btn=document.getElementById('place-order-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div> Placing order…';

  const orderNumber='DL-'+Date.now().toString().slice(-7);
  const earn=calcEarnPts(cartTotal());
  const orderRow={
    order_number:orderNumber,user_id:S.session?S.session.user.id:null,status:'confirmed',
    full_name:info.name,phone:info.phone,phone2:info.phone2,city:info.city,district:info.district,
    full_address:info.address,floor:info.floor,notes:info.notes,
    subtotal:cartSub(),delivery_fee:cartDelivery(),discount_amount:S.appliedDiscount||0,
    coupon_code:S.appliedCoupon?S.appliedCoupon.code:null,total:cartTotal(),points_earned:earn
  };
  const{data:order,error}=await sb.from('orders').insert(orderRow).select().single();
  if(error){btn.disabled=false;btn.textContent='Place order';toast('Could not place order — please try again');return}
  const items=S.cart.map(i=>({order_id:order.id,product_id:i.product_id,product_name:i.name,unit_price:i.price,quantity:i.qty,is_bundle:i.is_bundle,bundle_label:i.bundle_label}));
  await sb.from('order_items').insert(items);
  if(S.session){
    await sb.rpc('credit_points',{p_user:S.session.user.id,p_points:earn,p_note:'Order '+orderNumber});
    if(S.profile)S.profile.loyalty_points=(S.profile.loyalty_points||0)+earn;
  }
  if(S.appliedCoupon){
    await sb.rpc('redeem_coupon',{p_code:S.appliedCoupon.code});
  }
  S.currentOrder={number:orderNumber,earn};
  S.cart=[];saveCart();updateCartBadge();S.appliedDiscount=0;S.appliedCoupon=null;
  nav('success',null,false);
}
function pSuccess(){
  const o=S.currentOrder||{};
  return `<div class="page"><div style="text-align:center;padding:44px 18px;max-width:420px;margin:0 auto">
    <div style="font-size:3rem;margin-bottom:14px">✅</div>
    <h2 style="font-family:var(--font-d);font-size:1.4rem;margin-bottom:9px">Order placed!</h2>
    ${o.number?`<div class="card" style="display:inline-block;padding:9px 18px;margin-bottom:12px;font-size:.84rem;font-family:var(--font-m)">Order number: <strong>${esc(o.number)}</strong></div>`:''}
    ${o.earn?`<div class="pts-hero"><div class="pts-hero-num">+${o.earn}</div><div>points earned</div></div>`:''}
    <p style="color:var(--muted);font-size:.9rem;line-height:1.7;margin-bottom:18px">Thanks for shopping with Dash Lebanon. Our team will confirm your order and be in touch shortly.</p>
    <div style="display:flex;flex-direction:column;gap:9px">
      <button class="btn btn-primary" onclick="resetHome()">Back to store</button>
      <button class="btn btn-ghost" onclick="nav('orders',null,false)">تتبع طلبيs</button>
    </div>
  </div></div>`;
}
