/* =========================================================
   ACCOUNT — direct email/password auth (OTP/Firebase removed)
========================================================= */
let authTab='login';
function pAccount(){
  if(!S.session){app().innerHTML=pAuthForms();renderAuthBody();return}
  renderAccountLoggedIn();
}
function pAuthForms(){return `<div class="page" style="max-width:440px">
  <button class="back-link" onclick="goBack()">← Back</button>
  <div class="card form-card"><div class="auth-tabs" id="auth-tabs-nav">
    <button class="auth-tab ${authTab==='login'?'on':''}" onclick="setAuthTab('login')">Log in</button>
    <button class="auth-tab ${authTab==='register'?'on':''}" onclick="setAuthTab('register')">Register</button>
    <button class="auth-tab ${authTab==='forgot'?'on':''}" onclick="setAuthTab('forgot')">Forgot</button>
  </div><div id="auth-msg"></div><div id="auth-body"></div></div></div>`}
function setAuthTab(t){authTab=t;render();renderAuthBody()}
function renderAuthBody(){
 const body=document.getElementById('auth-body');if(!body)return;
 if(authTab==='login') body.innerHTML=`<div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="lg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="lg-pass" type="password" autocomplete="current-password"></div><button class="btn btn-primary" id="lg-btn" onclick="doLogin()">Log in</button>`;
 else if(authTab==='register') body.innerHTML=`<div class="frow2"><div class="fgroup"><label class="flabel">First name <span class="req">*</span></label><input class="finput" id="rg-fname"></div><div class="fgroup"><label class="flabel">Last name <span class="req">*</span></label><input class="finput" id="rg-lname"></div></div><div class="fgroup"><label class="flabel">Username <span class="req">*</span></label><input class="finput" id="rg-username"></div><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="rg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Phone number</label><input class="finput" id="rg-phone" type="tel" autocomplete="tel"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="rg-pass" type="password" autocomplete="new-password"></div><button class="btn btn-primary" id="rg-btn" onclick="doRegister()">Create account</button>`;
 else body.innerHTML=`<p class="muted-note">Enter your email and we'll send you a reset link.</p><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="fg-email" type="email" autocomplete="email"></div><button class="btn btn-primary" id="fg-btn" onclick="doForgot()">Send reset link</button>`;
}
function authMsg(text,ok){const el=document.getElementById('auth-msg');if(el)el.innerHTML=text?`<div class="alert ${ok?'alert-ok':'alert-err'}">${esc(text)}</div>`:''}
async function doLogin(){const email=document.getElementById('lg-email')?.value.trim(),pass=document.getElementById('lg-pass')?.value;if(!email||!pass)return authMsg('Please fill in all fields',false);const btn=document.getElementById('lg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.signInWithPassword({email,password:pass});btn.disabled=false;btn.textContent='Log in';if(error)return authMsg(error.message,false);await loadProfileAndWishlist();toast('Welcome back!');nav('account',null,false)}
async function doRegister(){const fname=document.getElementById('rg-fname').value.trim(),lname=document.getElementById('rg-lname').value.trim(),username=document.getElementById('rg-username').value.trim(),email=document.getElementById('rg-email').value.trim(),phone=document.getElementById('rg-phone').value.trim(),pass=document.getElementById('rg-pass').value;if(!fname||!lname||!username||!email||!pass)return authMsg('Please fill in all required fields',false);if(pass.length<6)return authMsg('Password must be at least 6 characters',false);const btn=document.getElementById('rg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{data,error}=await sb.auth.signUp({email,password:pass,options:{data:{first_name:fname,last_name:lname,username,phone}}});btn.disabled=false;btn.textContent='Create account';if(error)return authMsg(error.message,false);if(data.session){S.session=data.session;await loadProfileAndWishlist();toast('Welcome to Dash Lebanon!');nav('account',null,false)}else{authMsg('Account created. You can log in now.',true);setAuthTab('login')}}
async function doForgot(){const email=document.getElementById('fg-email')?.value.trim();if(!email)return authMsg('Please enter your email',false);const btn=document.getElementById('fg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});btn.disabled=false;btn.textContent='Send reset link';authMsg(error?error.message:'If that email is registered, a reset link is on its way.',!error)}

function renderAccountLoggedIn(){
  const p=S.profile||{};
  app().innerHTML=`<div class="page" style="max-width:520px">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="profile-hero">
      <div class="avatar-circ">${esc((p.first_name||'U')[0])}</div>
      <div><div style="font-weight:800">${esc(p.first_name||'')} ${esc(p.last_name||'')}</div><div style="color:var(--muted);font-size:.83rem;font-family:var(--font-m)">@${esc(p.username||'')}</div></div>
    </div>
    <div class="card" style="padding:4px">
      <div class="menu-list">
        <div class="menu-item" onclick="nav('orders')">📦 My Orders <span>›</span></div>
        <div class="menu-item" onclick="nav('wishlist')">♡ Wishlist <span>›</span></div>
        <div class="menu-item" onclick="nav('points')">★ My Points (${p.loyalty_points||0}) <span>›</span></div>
        <div class="menu-item" onclick="openDeliveryLocationEditor()">📍 Delivery location <span>${S.deliveryLocation?.confirmed_at?'Edit':'Add'} ›</span></div>
        <div class="menu-item" onclick="openEditProfile()">✎ Edit profile <span>›</span></div>
      </div>
    </div>
    <button class="btn btn-danger" style="margin-top:14px" onclick="doLogout()">Log out</button>
  </div>`;
}
/* Delivery location editor moved to js/22-location.js */
function openEditProfile(){
  const p=S.profile||{};
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">Edit profile</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">First name</label><input class="finput" id="ep-fname" value="${esc(p.first_name||'')}"></div>
      <div class="fgroup"><label class="flabel">Last name</label><input class="finput" id="ep-lname" value="${esc(p.last_name||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Phone</label><input class="finput" id="ep-phone" value="${esc(p.phone||'')}"></div>
    <button class="btn btn-primary" onclick="saveProfile()">Save changes</button>
  </div></div>`;
}
async function saveProfile(){
  const fname=document.getElementById('ep-fname').value.trim();
  const lname=document.getElementById('ep-lname').value.trim();
  const phone=document.getElementById('ep-phone').value.trim();
  const{error}=await sb.from('profiles').update({first_name:fname,last_name:lname,phone}).eq('id',S.session.user.id);
  if(error){toast('Could not save changes');return}
  S.profile={...S.profile,first_name:fname,last_name:lname,phone};
  closeModal();toast('Profile updated');renderAccountLoggedIn();
}
async function doLogout(){await sb.auth.signOut();if(window.firebase&&firebase.apps.length)await firebase.auth().signOut().catch(()=>{});S.profile=null;S.wishlist=[];S.deliveryLocation=null;toast('Logged out');resetHome()}
