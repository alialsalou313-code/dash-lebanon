/* =========================================================
   DARK MODE
========================================================= */
function applyDark(){document.documentElement.setAttribute('data-dark',S.dark?'1':'0');const dm=document.getElementById('drawer-dm-btn');if(dm)dm.textContent=(S.dark?'☀️ Light mode':'🌙 Dark mode')}
function toggleDark(){S.dark=!S.dark;localStorage.setItem('dl_dark',S.dark?'1':'0');applyDark()}
