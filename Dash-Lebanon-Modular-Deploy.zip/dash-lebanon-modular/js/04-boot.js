/* =========================================================
   BOOT
========================================================= */
async function boot(){
  // Safety: never leave the visitor stuck forever on the loading screen.
  const loadingSafetyTimer=setTimeout(()=>{
    const loader=document.getElementById('loading-screen');
    if(loader)loader.style.display='none';
  },8000);

  applyDark();
  try{
  const bootRequests=Promise.all([
    sb.auth.getSession(),
    sb.from('settings').select('*').eq('id',1).maybeSingle(),
    sb.from('categories').select('*').eq('is_active',true).order('sort_order'),
    sb.from('products').select('*, product_images(id,url,sort_order)').eq('is_active',true).order('created_at',{ascending:false}),
    sb.from('ai_public_settings').select('*').maybeSingle()
  ]);

  const bootTimeout=new Promise((_,reject)=>setTimeout(
    ()=>reject(new Error('Website loading timed out. Check Supabase connection and browser Console.')),
    7000
  ));

  const [{data:{session}},settingsRes,catRes,prodRes,aiPubRes]=await Promise.race([
    bootRequests,
    bootTimeout
  ]);
  S.session=session;
  S.settings=settingsRes.data||{store_name:'Dash Lebanon',currency_rate:90000,points_per_dollar:7,cancel_fee:4,free_cancel_hours:24,whatsapp_number:'96181877323',contact_email:'',instagram_url:'',facebook_url:'',tiktok_url:'',hero_title:'Everyday products, delivered fast.',hero_subtitle:'Quality home, kitchen & beauty finds — cash on delivery, anywhere in Lebanon.',announcement:''};
  S.categories=catRes.data||[];
  S.products=prodRes.data||[];
  S.aiPublic=aiPubRes.data||{enabled:false,assistant_name:'المساعد الذكي',welcome_message:''};
  applySettingsToChrome();
  if(session)await loadProfileAndWishlist();
  sb.auth.onAuthStateChange(async(event,sess)=>{
    S.session=sess;
    if(sess)await loadProfileAndWishlist(); else {S.profile=null;S.wishlist=[];S.isAdmin=false;S.deliveryLocation=null}
    updateChromeAuth();renderAdminNavVisibility();
  });
  // Resolve whatever URL the user actually landed on (deep link / refresh / shared link)
  const r=routeFromLocation();
  S.page=r.page;S.data=r.data;
  if(S.page==='admin')S.adminSection=r.data||'overview';
  if(S.page==='admin'&&!guardAdmin(true)){S.page='admin-login';S.data=null}
  document.getElementById('loading-screen').style.display='none';
  render();updateCartBadge();updateChromeAuth();renderAdminNavVisibility();
  syncUrl(false);
  initAiWidget();
  clearTimeout(loadingSafetyTimer);
  }catch(err){
    console.error('Boot error:',err);
    const loader=document.getElementById('loading-screen');
    if(loader)loader.style.display='none';
    clearTimeout(loadingSafetyTimer);
    const main=document.getElementById('main');
    if(main)main.innerHTML='<div style="padding:40px;text-align:center"><h2>Something went wrong loading the website.</h2><p>Please check the browser console for details.</p></div>';
  }
}
async function loadProfileAndWishlist(){
  const uid=S.session.user.id;
  const[{data:profile},{data:wl},{data:deliveryLocation}]=await Promise.all([
    sb.from('profiles').select('*').eq('id',uid).maybeSingle(),
    sb.from('wishlists').select('product_id').eq('user_id',uid),
    sb.from('delivery_locations').select('user_id,city,district,full_address,latitude,longitude,source,confirmed_at,updated_at').eq('user_id',uid).maybeSingle()
  ]);
  S.profile=profile;S.wishlist=(wl||[]).map(w=>w.product_id);
  S.deliveryLocation=deliveryLocation||null;
  S.isAdmin=!!(profile&&profile.role==='admin');
}
function renderAdminNavVisibility(){
  document.querySelectorAll('.admin-only-link').forEach(el=>el.classList.toggle('hide',!S.isAdmin));
}
function applySettingsToChrome(){
  const st=S.settings;
  document.title=st.store_name+' — '+(st.hero_title||'Shop');
  const ann=document.getElementById('announce');
  if(st.announcement){ann.textContent=st.announcement;ann.classList.remove('hide')}else ann.classList.add('hide');
  document.getElementById('footer-tag').textContent=st.hero_subtitle||'';
  document.getElementById('footer-year').textContent=new Date().getFullYear();
  const wa='https://wa.me/'+(st.whatsapp_number||'').replace(/\D/g,'');
  document.getElementById('wa-fab').href=wa;document.getElementById('drawer-wa').href=wa;document.getElementById('footer-wa').href=wa;
  document.getElementById('footer-email').href='mailto:'+(st.contact_email||'');
  document.getElementById('footer-email').textContent=st.contact_email||'';
  let soc='';
  if(st.instagram_url)soc+=`<a href="${esc(st.instagram_url)}" target="_blank">IG</a>`;
  if(st.facebook_url)soc+=`<a href="${esc(st.facebook_url)}" target="_blank">FB</a>`;
  if(st.tiktok_url)soc+=`<a href="${esc(st.tiktok_url)}" target="_blank">TT</a>`;
  document.getElementById('footer-soc').innerHTML=soc;
  document.getElementById('drawer-soc').innerHTML=soc;
}
function updateChromeAuth(){
  document.querySelectorAll('.nav-links button').forEach(b=>b.classList.toggle('on',b.dataset.nav===S.page));
  const dm=document.getElementById('drawer-dm-btn');if(dm)dm.textContent=(S.dark?'☀️ Light mode':'🌙 Dark mode');
  document.querySelectorAll('.admin-only-link').forEach(el=>el.classList.toggle('hide',!S.isAdmin));
}
