# Dash Lebanon — Modular Deploy (secured)

Static site (Netlify/Cloudflare Pages). Entry: `index.html`. Hosting: Vercel (`vercel.json` = SPA rewrite + security headers).

## Structure
- `js/` — one file per responsibility, loaded in order with `defer` (classic scripts: the UI uses inline handlers, so functions stay global)
  01 config · 02 state · 03 routing/utils · 04 boot · 05 theme · 06 router · 07 products · 08 home · 09 product-detail · 10 reviews · 11 wishlist · 12 cart · 13 checkout · 14 orders · 15 points · 16 account · 17 contact · 18 admin-login · 19 admin · 20 ai · **22 location** · **23 mobile-nav** · 21 app
- `css/` — main, admin, ai, responsive, **navigation** (bottom nav + "+" sheet), **location**
- `supabase/migrations/001_security_hardening.sql` — **run before deploying** (see SECURITY-REPORT.md)

## Rules
- The anon key in `js/01-config.js` is public by design. Never put a service-role key in frontend files.
- Prices, delivery fee, coupons, points and order cancellation are enforced in Postgres (`place_order`, `validate_coupon`, `cancel_order`), not in the browser.
- Location: asked once with an explanation, read once on user action, never tracked. Reverse geocoding uses the `reverse-geocode` Edge Function when `DELIVERY_REVERSE_GEOCODING_READY=true`, otherwise OpenStreetMap Nominatim (allowed by the CSP in `_headers`).
