/* =========================================================
   REVIEW MODAL
========================================================= */
function openReviewModal(pid){
  let rating=5;
  const root=document.getElementById('modal-root');
  root.innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">Write a review</div>
    <div class="star-pick" id="star-pick">${[1,2,3,4,5].map(n=>`<span class="${n<=5?'on':''}" data-n="${n}" onclick="pickStar(${n})">★</span>`).join('')}</div>
    <div class="fgroup"><label class="flabel">Your review <span class="req">*</span></label><textarea class="ftextarea" id="rv-text" placeholder="Share your experience with this product…"></textarea></div>
    <button class="btn btn-primary" onclick="submitReview('${pid}')">Submit review</button>
  </div></div>`;
  window._rvRating=5;
}
function pickStar(n){window._rvRating=n;document.querySelectorAll('#star-pick span').forEach(s=>s.classList.toggle('on',parseInt(s.dataset.n)<=n))}
async function submitReview(pid){
  const text=document.getElementById('rv-text').value.trim();
  if(!text){toast('Please write a comment');return}
  const{error}=await sb.from('reviews').insert({product_id:pid,user_id:S.session.user.id,rating:window._rvRating||5,comment:text,status:'pending'});
  if(error){toast('Could not submit review');return}
  closeModal();toast('Thanks! Your review will appear once approved.');
}
function closeModal(ev){if(ev&&ev.target.className!=='modal-ov')return;document.getElementById('modal-root').innerHTML=''}
