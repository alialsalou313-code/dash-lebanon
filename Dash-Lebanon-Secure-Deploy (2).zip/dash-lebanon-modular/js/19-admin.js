/* =========================================================
   ADMIN DASHBOARD
========================================================= */
function pAdmin(){
  app().innerHTML=`<div class="admin-shell">
    <div class="admin-sidebar">
      <div class="admin-sidebar-title">Dashboard</div>
      ${adminNavBtn('overview','📊 Overview')}
      ${adminNavBtn('orders','📦 Orders')}
      ${adminNavBtn('products','🏷 Products')}
      ${adminNavBtn('categories','🗂 Categories')}
      ${adminNavBtn('reviews','⭐ Reviews')}
      ${adminNavBtn('messages','✉ Messages')}
      <div class="admin-sidebar-title" style="margin-top:10px">Configuration</div>
      ${adminNavBtn('ai','✨ إعدادات الذكاء الاصطناعي')}
      ${adminNavBtn('settings','⚙ Store Settings')}
    </div>
    <div class="admin-main" id="admin-main">${skeletonAdminBlock()}</div>
  </div>`;
  loadAdminSection(S.adminSection||'overview');
}
function adminNavBtn(id,label){return `<button class="admin-nav-btn ${S.adminSection===id?'on':''}" onclick="navAdminSection('${id}')">${label}</button>`}
function navAdminSection(id){S.adminSection=id;nav('admin',id)}
function skeletonAdminBlock(){return `<div class="skel skel-row" style="width:40%"></div><div class="skel skel-row"></div><div class="skel skel-row"></div><div class="skel skel-row" style="width:70%"></div>`}
function adminEmptyBlock(ico,title,sub){return `<div class="empty-box"><div class="empty-ico">${ico}</div><div class="empty-ttl">${esc(title)}</div><div class="empty-sub">${esc(sub)}</div></div>`}
function adminErrorBlock(msg){return `<div class="alert alert-err">${esc(msg)}</div>`}
async function loadAdminSection(id){
  const main=document.getElementById('admin-main');if(!main)return;
  try{
    switch(id){
      case'overview':return await renderAdminOverview(main);
      case'orders':return await renderAdminOrders(main);
      case'products':return await renderAdminProducts(main);
      case'categories':return await renderAdminCategories(main);
      case'reviews':return await renderAdminReviews(main);
      case'messages':return await renderAdminMessages(main);
      case'ai':return await renderAdminAI(main);
      case'settings':return await renderAdminSettings(main);
      default:return await renderAdminOverview(main);
    }
  }catch(err){main.innerHTML=adminErrorBlock('Something went wrong loading this section.')}
}

/* ---- Overview ---- */
async function renderAdminOverview(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Overview</div></div><div class="stat-grid">${skeletonAdminBlock()}</div>`;
  const[{count:ordersCount},{count:prodCount},{count:userCount},{count:msgCount},{data:revData}]=await Promise.all([
    sb.from('orders').select('*',{count:'exact',head:true}),
    sb.from('products').select('*',{count:'exact',head:true}),
    sb.from('profiles').select('*',{count:'exact',head:true}),
    sb.from('contact_messages').select('*',{count:'exact',head:true}).eq('is_read',false),
    sb.from('orders').select('total').neq('status','cancelled')
  ]);
  const revenue=(revData||[]).reduce((s,o)=>s+parseFloat(o.total||0),0);
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Overview</div></div>
  <div class="stat-grid">
    <div class="card stat-card"><div class="stat-num">${ordersCount||0}</div><div class="stat-lbl">Total orders</div></div>
    <div class="card stat-card"><div class="stat-num">${fmt(revenue)}</div><div class="stat-lbl">Revenue (non-cancelled)</div></div>
    <div class="card stat-card"><div class="stat-num">${prodCount||0}</div><div class="stat-lbl">Products</div></div>
    <div class="card stat-card"><div class="stat-num">${userCount||0}</div><div class="stat-lbl">Registered users</div></div>
    <div class="card stat-card"><div class="stat-num">${msgCount||0}</div><div class="stat-lbl">Unread messages</div></div>
  </div>
  <div class="card" style="padding:18px">
    <div class="form-title" style="margin-bottom:10px">Quick links</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px">
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('orders')">Manage orders</button>
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('products')">Manage products</button>
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('ai')">Configure AI assistant</button>
    </div>
  </div>`;
}

/* ---- Orders ---- */
let adminOrderFilter='all';
async function renderAdminOrders(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Orders</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('orders').select('*, order_items(*)').order('created_at',{ascending:false}).limit(300);
  if(error){main.innerHTML=adminErrorBlock('Could not load orders.');return}
  window._adminOrders=data||[];
  drawAdminOrders(main);
}
function drawAdminOrders(main){
  const list=(window._adminOrders||[]).filter(o=>adminOrderFilter==='all'||o.status===adminOrderFilter);
  const tabs=['all','pending','confirmed','processing','shipping','delivered','cancelled'];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Orders</div></div>
  <div class="admin-tabs">${tabs.map(t=>`<button class="admin-tab ${adminOrderFilter===t?'on':''}" onclick="setAdminOrderFilter('${t}')">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div>
  ${!list.length?adminEmptyBlock('📦','No orders','No orders match this filter yet.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th></tr>
    ${list.map(o=>`<tr class="clickable" onclick="openAdminOrder('${o.id}')">
      <td class="mono">${esc(o.order_number)}</td><td>${esc(o.full_name||'—')}</td><td>${o.order_items.length}</td><td>${fmt(o.total)}</td>
      <td><span class="status-badge st-${o.status}">${o.status}</span></td><td>${new Date(o.created_at).toLocaleDateString()}</td>
    </tr>`).join('')}
  </table></div>`}`;
}
function setAdminOrderFilter(t){adminOrderFilter=t;drawAdminOrders(document.getElementById('admin-main'))}
function openAdminOrder(id){
  const o=(window._adminOrders||[]).find(x=>x.id===id);if(!o)return;
  const statuses=['pending','confirmed','processing','shipping','delivered','cancelled'];
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:520px">
    <div class="modal-handle"></div>
    <div class="modal-title">${esc(o.order_number)}</div>
    <div class="muted-note" style="margin-bottom:12px">${esc(o.full_name)} · ${esc(o.phone)}<br>${esc(o.city)}, ${esc(o.district)} — ${esc(o.full_address)}</div>
    ${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}
    <div class="summary-row total" style="margin-top:6px"><span>Total</span><span>${fmt(o.total)}</span></div>
    <div class="fgroup" style="margin-top:14px"><label class="flabel">Status</label>
      <select class="fselect" id="adm-order-status">${statuses.map(s=>`<option value="${s}" ${s===o.status?'selected':''}>${s}</option>`).join('')}</select>
    </div>
    <button class="btn btn-primary" onclick="saveOrderStatus('${o.id}')">Save status</button>
  </div></div>`;
}
async function saveOrderStatus(id){
  const status=document.getElementById('adm-order-status').value;
  const{error}=await sb.from('orders').update({status}).eq('id',id);
  if(error){toast('Could not update order');return}
  const o=(window._adminOrders||[]).find(x=>x.id===id);if(o)o.status=status;
  closeModal();toast('Order updated');drawAdminOrders(document.getElementById('admin-main'));
}

/* ---- Products ---- */
async function renderAdminProducts(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Products</div></div>${skeletonAdminBlock()}`;
  const[{data:prods,error},{data:cats}]=await Promise.all([
    sb.from('products').select('*, product_images(id,url,sort_order)').order('created_at',{ascending:false}),
    sb.from('categories').select('*').order('sort_order')
  ]);
  if(error){main.innerHTML=adminErrorBlock('Could not load products.');return}
  window._adminProducts=prods||[];window._adminCats=cats||[];
  drawAdminProducts(main);
}
function drawAdminProducts(main){
  const list=window._adminProducts||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Products</div><button class="btn btn-primary btn-sm" onclick="openProductModal()">+ Add product</button></div>
  ${!list.length?adminEmptyBlock('🏷','No products yet','Add your first product to get started.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Product</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr>
    ${list.map(p=>`<tr>
      <td><div class="prod-cell"><img class="thumb-24" src="${esc(coverImg(p))}" onerror="this.src='https://placehold.co/60x60/e7ebf3/98a2b8?text=?'">${esc(p.name)}</div></td>
      <td>${esc((window._adminCats||[]).find(c=>c.id===p.category_id)?.name||'—')}</td>
      <td>${fmt(p.price)}</td>
      <td><span class="status-badge ${p.is_active?'st-approved':'st-user'}">${p.is_active?'Active':'Hidden'}</span></td>
      <td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openProductModal('${p.id}')">Edit</button> <span class="danger-text" onclick="deleteProduct('${p.id}')">Delete</span></td>
    </tr>`).join('')}
  </table></div>`}`;
}
function openProductModal(id){
  const p=id?(window._adminProducts||[]).find(x=>x.id===id):null;
  const cats=window._adminCats||[];
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:520px">
    <div class="modal-handle"></div><div class="modal-title">${p?'Edit product':'Add product'}</div>
    <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="pm-name" value="${esc(p?.name||'')}"></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Price <span class="req">*</span></label><input class="finput" id="pm-price" type="number" step="0.01" value="${p?.price??''}"></div>
      <div class="fgroup"><label class="flabel">Compare-at price</label><input class="finput" id="pm-compare" type="number" step="0.01" value="${p?.compare_at_price??''}"></div>
    </div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Legacy product delivery price (not used; nationwide fee is $4)</label><input class="finput" id="pm-delivery" type="number" step="0.01" value="${p?.delivery_price??0}"></div>
      <div class="fgroup"><label class="flabel">Category</label><select class="fselect" id="pm-cat"><option value="">— None —</option>${cats.map(c=>`<option value="${c.id}" ${p?.category_id===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div>
    </div>
    <div class="fgroup"><label class="flabel">Image URLs (واحد بكل سطر — يدعم 50+)</label><textarea class="ftextarea" id="pm-image-urls" placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg">${esc((p?.product_images||[]).map(x=>x.url).join('\n'))}</textarea></div>
    <div class="fgroup"><label class="flabel">رفع صور من الجهاز (اختيار عدة صور)</label><input class="finput" id="pm-files" type="file" accept="image/*" multiple><div class="muted-note">الصور تُرفع إلى Supabase Storage وتُربط بالمنتج.</div></div>
    <div class="fgroup"><label class="flabel">Description</label><textarea class="ftextarea" id="pm-desc">${esc(p?.description||'')}</textarea></div>
    <div class="toggle-row" style="padding:0 0 14px"><div class="toggle-lbl">Active (visible on the store)</div><label class="switch"><input type="checkbox" id="pm-active" ${p?(p.is_active?'checked':''):'checked'}><span class="switch-track"></span></label></div>
    <button class="btn btn-primary" onclick="saveProduct(${p?`'${p.id}'`:'null'})">Save product</button>
  </div></div>`;
}
async function saveProduct(id){
  const row={
    name:document.getElementById('pm-name').value.trim(),
    price:parseFloat(document.getElementById('pm-price').value)||0,
    compare_at_price:document.getElementById('pm-compare').value?parseFloat(document.getElementById('pm-compare').value):null,
    delivery_price:parseFloat(document.getElementById('pm-delivery').value)||0,
    category_id:document.getElementById('pm-cat').value||null,
    description:document.getElementById('pm-desc').value.trim(),
    is_active:document.getElementById('pm-active').checked,
  };
  if(!row.name){toast('Product name is required');return}
  let productId=id;
  const saved=id?await sb.from('products').update(row).eq('id',id).select().single():await sb.from('products').insert(row).select().single();
  if(saved.error){console.error(saved.error);toast('Could not save product');return}
  productId=saved.data.id;
  const urls=[...new Set(document.getElementById('pm-image-urls').value.split(/\n+/).map(x=>x.trim()).filter(x=>/^https?:\/\//i.test(x)))];
  const files=[...document.getElementById('pm-files').files];
  const existing=(id?(window._adminProducts||[]).find(x=>x.id===id)?.product_images||[]:[]);
  const rows=[...urls.map((url,i)=>({product_id:productId,url,sort_order:i})),...existing.filter(x=>!urls.includes(x.url)).map((x,i)=>({product_id:productId,url:x.url,sort_order:urls.length+i}))];
  for(let i=0;i<files.length;i++){
    const f=files[i], safe=f.name.replace(/[^\w.\-]/g,'_');
    const path=`${productId}/${Date.now()}-${i}-${safe}`;
    const up=await sb.storage.from('product-images').upload(path,f,{upsert:false,contentType:f.type});
    if(up.error){console.error(up.error);toast('تم حفظ المنتج لكن تعذر رفع إحدى الصور');continue}
    const pub=sb.storage.from('product-images').getPublicUrl(path).data.publicUrl;
    rows.push({product_id:productId,url:pub,sort_order:rows.length});
  }
  if(id) await sb.from('product_images').delete().eq('product_id',productId);
  if(rows.length){const r=await sb.from('product_images').insert(rows);if(r.error)console.error(r.error)}
  if(rows[0]?.url) await sb.from('products').update({cover_image:rows[0].url}).eq('id',productId);
  closeModal();toast('Product saved');renderAdminProducts(document.getElementById('admin-main'));
  const{data}=await sb.from('products').select('*, product_images(id,url,sort_order)').eq('is_active',true).order('created_at',{ascending:false});
  S.products=data||[];
}
async function deleteProduct(id){
  if(!confirm('Delete this product? This cannot be undone.'))return;
  const{error}=await sb.from('products').delete().eq('id',id);
  if(error){toast('Could not delete product');return}
  toast('Product deleted');renderAdminProducts(document.getElementById('admin-main'));
}

/* ---- Categories ---- */
async function renderAdminCategories(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Categories</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('categories').select('*').order('sort_order');
  if(error){main.innerHTML=adminErrorBlock('Could not load categories.');return}
  window._adminCats2=data||[];
  drawAdminCategories(main);
}
function drawAdminCategories(main){
  const list=window._adminCats2||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Categories</div><button class="btn btn-primary btn-sm" onclick="openCategoryModal()">+ Add category</button></div>
  ${!list.length?adminEmptyBlock('🗂','No categories yet','Add a category to organize your products.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Name</th><th>Slug</th><th>Status</th><th></th></tr>
    ${list.map(c=>`<tr><td>${esc(c.name)}</td><td class="mono">${esc(c.slug)}</td><td><span class="status-badge ${c.is_active?'st-approved':'st-user'}">${c.is_active?'Active':'Hidden'}</span></td>
    <td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openCategoryModal('${c.id}')">Edit</button> <span class="danger-text" onclick="deleteCategory('${c.id}')">Delete</span></td></tr>`).join('')}
  </table></div>`}`;
}
function openCategoryModal(id){
  const c=id?(window._adminCats2||[]).find(x=>x.id===id):null;
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">${c?'Edit category':'Add category'}</div>
    <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="cm-name" value="${esc(c?.name||'')}"></div>
    <div class="fgroup"><label class="flabel">Slug <span class="req">*</span></label><input class="finput" id="cm-slug" value="${esc(c?.slug||'')}" placeholder="e.g. kitchen"></div>
    <div class="toggle-row" style="padding:0 0 14px"><div class="toggle-lbl">Active</div><label class="switch"><input type="checkbox" id="cm-active" ${c?(c.is_active?'checked':''):'checked'}><span class="switch-track"></span></label></div>
    <button class="btn btn-primary" onclick="saveCategory(${c?`'${c.id}'`:'null'})">Save category</button>
  </div></div>`;
}
async function saveCategory(id){
  const row={name:document.getElementById('cm-name').value.trim(),slug:document.getElementById('cm-slug').value.trim().toLowerCase().replace(/\s+/g,'-'),is_active:document.getElementById('cm-active').checked};
  if(!row.name||!row.slug){toast('Name and slug are required');return}
  const{error}=id?await sb.from('categories').update(row).eq('id',id):await sb.from('categories').insert(row);
  if(error){toast('Could not save category');return}
  closeModal();toast('Category saved');renderAdminCategories(document.getElementById('admin-main'));
  const{data}=await sb.from('categories').select('*').eq('is_active',true).order('sort_order');S.categories=data||[];
}
async function deleteCategory(id){
  if(!confirm('Delete this category?'))return;
  const{error}=await sb.from('categories').delete().eq('id',id);
  if(error){toast('Could not delete — make sure no products use it.');return}
  toast('Category deleted');renderAdminCategories(document.getElementById('admin-main'));
}

/* ---- Reviews moderation ---- */
async function renderAdminReviews(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Reviews</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('reviews').select('*, profiles(first_name,last_name), products(name)').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load reviews.');return}
  window._adminReviews=data||[];drawAdminReviews(main);
}
function drawAdminReviews(main){
  const list=window._adminReviews||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Reviews</div></div>
  ${!list.length?adminEmptyBlock('⭐','No reviews yet','Customer reviews will show up here for moderation.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th></th></tr>
    ${list.map(r=>`<tr><td>${esc(r.products?.name||'—')}</td><td>${esc(r.profiles?.first_name||'')} ${esc(r.profiles?.last_name||'')}</td><td>${'★'.repeat(r.rating)}</td><td style="max-width:220px">${esc(r.comment)}</td>
    <td><span class="status-badge st-${r.status}">${r.status}</span></td>
    <td style="white-space:nowrap">${r.status!=='approved'?`<button class="btn btn-ghost btn-sm" onclick="setReviewStatus('${r.id}','approved')">Approve</button>`:''} ${r.status!=='rejected'?`<span class="danger-text" onclick="setReviewStatus('${r.id}','rejected')">Reject</span>`:''}</td></tr>`).join('')}
  </table></div>`}`;
}
async function setReviewStatus(id,status){
  const{error}=await sb.from('reviews').update({status}).eq('id',id);
  if(error){toast('Could not update review');return}
  const r=(window._adminReviews||[]).find(x=>x.id===id);if(r)r.status=status;
  toast('Review updated');drawAdminReviews(document.getElementById('admin-main'));
}

/* ---- Contact messages ---- */
async function renderAdminMessages(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Messages</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('contact_messages').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load messages.');return}
  window._adminMsgs=data||[];drawAdminMessages(main);
}
function drawAdminMessages(main){
  const list=window._adminMsgs||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Messages</div></div>
  ${!list.length?adminEmptyBlock('✉','No messages','Contact form submissions will appear here.'):
  list.map(m=>`<div class="card" style="padding:16px;margin-bottom:10px;${m.is_read?'':'border-color:var(--primary)'}">
    <div style="display:flex;justify-content:space-between;gap:10px"><strong>${esc(m.name)}</strong><span class="muted-note">${new Date(m.created_at).toLocaleString()}</span></div>
    <div class="muted-note" style="margin:4px 0">${esc(m.phone)}</div>
    <div style="font-size:.86rem;margin:8px 0">${esc(m.message)}</div>
    <div style="display:flex;gap:8px">${!m.is_read?`<button class="btn btn-ghost btn-sm" onclick="markMsgRead('${m.id}')">Mark read</button>`:''}<span class="danger-text" onclick="deleteMsg('${m.id}')">Delete</span></div>
  </div>`).join('')}`;
}
async function markMsgRead(id){await sb.from('contact_messages').update({is_read:true}).eq('id',id);const m=(window._adminMsgs||[]).find(x=>x.id===id);if(m)m.is_read=true;drawAdminMessages(document.getElementById('admin-main'))}
async function deleteMsg(id){if(!confirm('Delete this message?'))return;await sb.from('contact_messages').delete().eq('id',id);window._adminMsgs=(window._adminMsgs||[]).filter(x=>x.id!==id);drawAdminMessages(document.getElementById('admin-main'))}

/* ---- إعدادات الذكاء الاصطناعي ---- */
async function renderAdminAI(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">إعدادات الذكاء الاصطناعي</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('ai_settings').select('*').eq('id',1).maybeSingle();
  if(error||!data){main.innerHTML=adminErrorBlock('تعذر تحميل إعدادات الذكاء الاصطناعي.');return}
  window._adminAI=data;
  drawAdminAI(main);
}
function drawAdminAI(main){
  const a=window._adminAI;
  main.innerHTML=`<div class="admin-head"><div class="admin-title">إعدادات الذكاء الاصطناعي</div></div>
  <div class="card" style="padding:18px;margin-bottom:16px">
    <div class="toggle-row"><div><div class="toggle-lbl">تفعيل المساعد الذكي</div><div class="toggle-sub">تشغيل أو إيقاف نافذة المحادثة الذكية لجميع الزوار.</div></div><label class="switch"><input type="checkbox" id="ai-enabled" ${a.enabled?'checked':''}><span class="switch-track"></span></label></div>
  </div>
  <div class="card form-card">
    <div class="form-title">عام</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">اسم المساعد</label><input class="finput" id="ai-name" value="${esc(a.assistant_name||'')}"></div>
      <div class="fgroup"><label class="flabel">اسم الموديل</label><input class="finput" id="ai-model" value="${esc(a.model_name||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">رسالة الترحيب</label><textarea class="ftextarea" id="ai-welcome">${esc(a.welcome_message||'')}</textarea></div>
  </div>
  <div class="card form-card">
    <div class="form-title">المزوّد</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">المزوّد</label><select class="fselect" id="ai-provider"><option value="anthropic" ${a.provider==='anthropic'?'selected':''}>Anthropic</option><option value="openai" ${a.provider==='openai'?'selected':''}>OpenAI-compatible</option></select></div>
      <div class="fgroup"><label class="flabel">رابط API</label><input class="finput" id="ai-url" value="${esc(a.api_url||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">مفتاح API</label><input class="finput" id="ai-apikey" type="password" autocomplete="off" placeholder="${a.api_key?'•••••••••••••••• (saved — leave blank to keep)':'sk-...'}"></div>
    <div class="alert" style="background:rgba(224,67,62,.08);color:var(--danger)">⚠️ يُخزَّن المفتاح في قاعدة البيانات وقد يصل إلى جلسة المتصفح. يجب الحفاظ على أمان حساب الإدارة وإعدادات قاعدة البيانات.</div>
    <button class="btn btn-ghost" type="button" style="width:auto;padding:11px 18px;margin-top:4px" onclick="testAiConnection()" id="ai-test-btn">🔌 اختبار الاتصال بالـAI / Test Connection</button>
    <div id="ai-test-result" style="margin-top:12px"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">التعليمات</div>
    <div class="fgroup"><label class="flabel">تعليمات النظام</label><textarea class="ftextarea" id="ai-instructions" style="min-height:160px">${esc(a.system_instructions||'')}</textarea></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">المواضيع المسموح بها</label><textarea class="ftextarea" id="ai-allowed">${esc(a.allowed_topics||'')}</textarea></div>
      <div class="fgroup"><label class="flabel">المواضيع الممنوعة</label><textarea class="ftextarea" id="ai-restricted">${esc(a.restricted_topics||'')}</textarea></div>
    </div>
  </div>
  <div class="card form-card">
    <div class="form-title">متقدم</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">درجة الحرارة (0–1)</label><input class="finput" id="ai-temp" type="number" min="0" max="1" step="0.1" value="${a.temperature??0.4}"></div>
      <div class="fgroup"><label class="flabel">الحد الأقصى لرموز الرد</label><input class="finput" id="ai-maxtok" type="number" value="${a.max_tokens??700}"></div>
    </div>
  </div>
  <div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveAiSettings()">حفظ إعدادات الذكاء الاصطناعي</button></div>`;
}
async function saveAiSettings(){
  const apiKeyInput=document.getElementById('ai-apikey').value.trim();
  const row={
    enabled:document.getElementById('ai-enabled').checked,
    assistant_name:document.getElementById('ai-name').value.trim()||'المساعد الذكي',
    model_name:document.getElementById('ai-model').value.trim(),
    welcome_message:document.getElementById('ai-welcome').value.trim(),
    provider:document.getElementById('ai-provider').value,
    api_url:document.getElementById('ai-url').value.trim(),
    system_instructions:document.getElementById('ai-instructions').value.trim(),
    allowed_topics:document.getElementById('ai-allowed').value.trim(),
    restricted_topics:document.getElementById('ai-restricted').value.trim(),
    temperature:parseFloat(document.getElementById('ai-temp').value)||0.4,
    max_tokens:parseInt(document.getElementById('ai-maxtok').value)||700,
    updated_at:new Date().toISOString()
  };
  if(apiKeyInput)row.api_key=apiKeyInput; // leave unchanged if left blank
  const{error}=await sb.from('ai_settings').update(row).eq('id',1);
  if(error){toast('تعذر حفظ إعدادات الذكاء الاصطناعي');return}
  toast('تم حفظ إعدادات الذكاء الاصطناعي');
  const{data}=await sb.from('ai_public_settings').select('*').maybeSingle();
  S.aiPublic=data||S.aiPublic;initAiWidget();
}

/* ---- AI Test Connection ---- */
function aiTestReasonLabel(reason){
  return({
    missing_api_key:'❌ API Key مفقود / API Key is missing',
    missing_model:'❌ Model غير محدد / اسم الموديل is missing',
    missing_url:'❌ رابط API غير محدد / رابط API is missing',
    unauthorized:'❌ API Key غير صحيح (Unauthorized / 401)',
    rate_limited:'❌ Rate Limit — تم تجاوز حد الطلبات (429)',
    quota_or_billing:'❌ مشكلة في الرصيد أو حدود الاستخدام (402/403)',
    model_not_found:'❌ Model غير صحيح أو غير متاح (404)',
    bad_request:'❌ الطلب غير صالح (400) — تحقق من اسم الـModel أو الإعدادات',
    provider_error:'❌ خطأ من مزوّد الـAI (OpenRouter/Anthropic/OpenAI)',
    network_error:'❌ تعذر الوصول للسيرفر (مشكلة اتصال شبكة)',
    edge_function_error:'❌ مشكلة داخل Supabase Edge Function',
    disabled:'⚠️ مساعد الـAI معطّل حالياً (فعّل الزر بالأعلى)',
  })[reason]||'❌ خطأ غير معروف / Unknown error';
}
async function testAiConnection(){
  const btn=document.getElementById('ai-test-btn');
  const box=document.getElementById('ai-test-result');
  const apiKeyInput=document.getElementById('ai-apikey').value.trim(); // sent over HTTPS to our own edge function only; never logged or echoed back
  const payload={
    action:'test',
    provider:document.getElementById('ai-provider').value,
    api_url:document.getElementById('ai-url').value.trim(),
    model_name:document.getElementById('ai-model').value.trim(),
    temperature:parseFloat(document.getElementById('ai-temp').value)||0.4,
    max_tokens:parseInt(document.getElementById('ai-maxtok').value)||700,
  };
  if(apiKeyInput)payload.api_key=apiKeyInput; // omitted => edge function uses the saved key from the database
  btn.disabled=true;const oldLabel=btn.textContent;btn.innerHTML='<span class="spin"></span> جاري الاختبار…';
  box.innerHTML='';
  try{
    const{data,error}=await sb.functions.invoke(AI_FUNCTION_NAME,{body:payload});
    if(error||!data){
      box.innerHTML=`<div class="alert alert-err">❌ تعذر الوصول إلى Edge Function باسم "${esc(AI_FUNCTION_NAME)}". تأكد من نشرها على مشروع Supabase الحالي.<br><span class="mono" style="font-size:.76rem">${esc((error&&error.message)||'no response')}</span></div>`;
    }else if(data.ok){
      box.innerHTML=`<div class="alert alert-ok">
        ✅ تم الاتصال بالـAI بنجاح<br>
        <strong>المزوّد:</strong> ${esc(data.provider||'—')}<br>
        <strong>Model:</strong> ${esc(data.model||'—')}<br>
        API Key يعمل بشكل صحيح — الـAI جاهز للاستخدام.
      </div>`;
    }else{
      box.innerHTML=`<div class="alert alert-err">
        ${aiTestReasonLabel(data.reason)}<br>
        ${data.http_status?`<strong>HTTP Status:</strong> ${esc(String(data.http_status))}<br>`:''}
        ${data.error_code?`<strong>Error Code:</strong> ${esc(String(data.error_code))}<br>`:''}
        ${data.stage?`<strong>مكان الخطأ:</strong> ${esc(data.stage)}<br>`:''}
        ${data.message?`<div class="mono" style="font-size:.76rem;margin-top:6px;white-space:pre-wrap">${esc(data.message)}</div>`:''}
      </div>`;
    }
  }catch(err){
    box.innerHTML=`<div class="alert alert-err">❌ خطأ غير متوقع أثناء الاختبار.<br><span class="mono" style="font-size:.76rem">${esc(err.message||String(err))}</span></div>`;
  }
  btn.disabled=false;btn.textContent=oldLabel;
}

/* ---- Store settings ---- */
async function renderAdminSettings(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Store Settings</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('settings').select('*').eq('id',1).maybeSingle();
  if(error||!data){main.innerHTML=adminErrorBlock('Could not load settings.');return}
  window._adminSettings=data;drawAdminSettings(main);
}
function drawAdminSettings(main){
  const s=window._adminSettings;
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Store Settings</div></div>
  <div class="card form-card">
    <div class="form-title">Store</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Store name</label><input class="finput" id="st-name" value="${esc(s.store_name||'')}"></div>
      <div class="fgroup"><label class="flabel">Currency rate (USD→LBP)</label><input class="finput" id="st-rate" type="number" value="${s.currency_rate??0}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Hero title</label><input class="finput" id="st-hero" value="${esc(s.hero_title||'')}"></div>
    <div class="fgroup"><label class="flabel">Hero subtitle</label><textarea class="ftextarea" id="st-sub">${esc(s.hero_subtitle||'')}</textarea></div>
    <div class="fgroup"><label class="flabel">Announcement bar</label><input class="finput" id="st-announce" value="${esc(s.announcement||'')}"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">Loyalty & cancellation</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Points per $</label><input class="finput" id="st-pts" type="number" value="${s.points_per_dollar??0}"></div>
      <div class="fgroup"><label class="flabel">Cancel fee ($)</label><input class="finput" id="st-fee" type="number" value="${s.cancel_fee??0}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Free cancellation window (hours)</label><input class="finput" id="st-hours" type="number" value="${s.free_cancel_hours??24}"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">Contact & social</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">WhatsApp number</label><input class="finput" id="st-wa" value="${esc(s.whatsapp_number||'')}"></div>
      <div class="fgroup"><label class="flabel">Contact email</label><input class="finput" id="st-email" value="${esc(s.contact_email||'')}"></div>
    </div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Instagram URL</label><input class="finput" id="st-ig" value="${esc(s.instagram_url||'')}"></div>
      <div class="fgroup"><label class="flabel">Facebook URL</label><input class="finput" id="st-fb" value="${esc(s.facebook_url||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">TikTok URL</label><input class="finput" id="st-tt" value="${esc(s.tiktok_url||'')}"></div>
  </div>
  <div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveStoreSettings()">Save settings</button></div>`;
}
async function saveStoreSettings(){
  const row={
    store_name:document.getElementById('st-name').value.trim(),
    currency_rate:parseFloat(document.getElementById('st-rate').value)||0,
    hero_title:document.getElementById('st-hero').value.trim(),
    hero_subtitle:document.getElementById('st-sub').value.trim(),
    announcement:document.getElementById('st-announce').value.trim(),
    points_per_dollar:parseFloat(document.getElementById('st-pts').value)||0,
    cancel_fee:parseFloat(document.getElementById('st-fee').value)||0,
    free_cancel_hours:parseInt(document.getElementById('st-hours').value)||24,
    whatsapp_number:document.getElementById('st-wa').value.trim(),
    contact_email:document.getElementById('st-email').value.trim(),
    instagram_url:document.getElementById('st-ig').value.trim(),
    facebook_url:document.getElementById('st-fb').value.trim(),
    tiktok_url:document.getElementById('st-tt').value.trim(),
  };
  const{error}=await sb.from('settings').update(row).eq('id',1);
  if(error){toast('Could not save settings');return}
  toast('Store settings saved');
  S.settings={...S.settings,...row};applySettingsToChrome();
}
