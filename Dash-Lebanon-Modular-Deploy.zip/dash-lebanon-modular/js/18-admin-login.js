/* =========================================================
   ADMIN LOGIN
========================================================= */
function pAdminLogin(){
  if(S.session&&S.isAdmin){nav('admin','overview',false);return}
  app().innerHTML=`<div class="page" style="max-width:460px;padding-top:42px">
    <div class="card" style="padding:28px;box-shadow:var(--shadow-lg)">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px"><div style="width:48px;height:48px;border-radius:14px;display:grid;place-items:center;background:var(--primary);color:#fff;font-size:22px">🔐</div><div><div class="disp" style="font-size:1.5rem">Admin Login</div><div style="color:var(--muted);font-size:.84rem">Dash Lebanon Administration</div></div></div>
      <div id="admin-login-msg"></div>
      <div class="fgroup"><label class="flabel">Username</label><input class="finput" id="admin-username" autocomplete="username" placeholder="admin" onkeydown="if(event.key==='Enter')doAdminLogin()"></div>
      <div class="fgroup"><label class="flabel">Password</label><input class="finput" id="admin-password" type="password" autocomplete="current-password" placeholder="Enter password" onkeydown="if(event.key==='Enter')doAdminLogin()"></div>
      <button class="btn btn-primary" id="admin-login-btn" onclick="doAdminLogin()">Sign in to Admin Dashboard</button>
      <div style="margin-top:14px;color:var(--muted);font-size:.78rem;text-align:center">This area is restricted to authorized administrators.</div>
    </div>
  </div>`;
}
function adminLoginMsg(text,ok){const el=document.getElementById('admin-login-msg');if(!el)return;el.innerHTML=text?`<div class="alert ${ok?'alert-ok':'alert-err'}">${esc(text)}</div>`:''}
async function doAdminLogin(){
  const username=document.getElementById('admin-username').value.trim();
  const password=document.getElementById('admin-password').value;
  if(!username||!password){adminLoginMsg('Please enter your username and password.',false);return}
  const btn=document.getElementById('admin-login-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  /* The SQL bootstrap account uses this email. The page intentionally asks for the administrator email. */
  const ADMIN_BOOTSTRAP_EMAIL='alialsalou313@gmail.com';
  if(username.toLowerCase()!==ADMIN_BOOTSTRAP_EMAIL.toLowerCase()){btn.disabled=false;btn.textContent='Sign in to Admin Dashboard';adminLoginMsg('Invalid admin email or password.',false);return}
  const {error}=await sb.auth.signInWithPassword({email:ADMIN_BOOTSTRAP_EMAIL,password});
  btn.disabled=false;btn.textContent='Sign in to Admin Dashboard';
  if(error){adminLoginMsg('Invalid admin email or password.',false);return}
  const {data:{session}}=await sb.auth.getSession();S.session=session;
  await loadProfileAndWishlist();
  if(!S.isAdmin){await sb.auth.signOut();S.session=null;S.profile=null;adminLoginMsg('This account is not configured as an administrator.',false);return}
  toast('Welcome to the Admin Dashboard');nav('admin','overview');
}
