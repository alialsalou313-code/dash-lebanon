-- AI chat storage. Accessed ONLY by the ai-chat Edge Function (service role).
-- RLS is enabled with no policies => browsers (anon/authenticated) cannot read or write these tables.
create table if not exists public.ai_conversations (
  id uuid primary key default gen_random_uuid(),
  session_id text not null check (length(session_id) <= 80),
  user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists ai_conv_session_idx on public.ai_conversations(session_id, created_at desc);

create table if not exists public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.ai_conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists ai_msg_conv_idx on public.ai_messages(conversation_id, created_at);

alter table public.ai_conversations enable row level security;
alter table public.ai_messages enable row level security;
revoke all on public.ai_conversations, public.ai_messages from anon, authenticated;

select 'AI chat tables installed successfully' as status;
