-- Dash Lebanon — security hardening (ADDITIVE; no DROP TABLE / DROP COLUMN / CASCADE).
-- Run in Supabase SQL Editor. Review section 0 first. Safe to re-run.
-- Assumes existing: profiles(id, role, loyalty_points), orders, order_items, coupons,
-- products(price, bundle_qty, bundle_price, is_active), settings(id=1, points_per_dollar),
-- functions credit_points(p_user uuid, p_points int, p_note text) and redeem_coupon(p_code text).

-- 0) AUDIT (read-only): review every existing policy; permissive policies are OR-ed,
--    so one weak policy (e.g. "using (true)" on orders/profiles) defeats the rest.
-- select tablename, policyname, cmd, roles, qual, with_check from pg_policies where schemaname='public' order by 1,2;

-- 1) Admin helper
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public as
$$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;

-- 2) Block privilege escalation / points tampering on profiles (client roles only)
create or replace function public.guard_profiles() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if current_user in ('anon','authenticated') and not public.is_admin() then
    if tg_op='INSERT' then
      if new.role='admin' then raise exception 'forbidden'; end if;
      new.loyalty_points:=0;
    elsif new.role is distinct from old.role or new.loyalty_points is distinct from old.loyalty_points then
      raise exception 'forbidden';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_profiles on public.profiles;
create trigger trg_guard_profiles before insert or update on public.profiles
  for each row execute function public.guard_profiles();

-- 3) Orders can only be changed by admins directly; customers use cancel_order()
create or replace function public.guard_orders() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if current_user in ('anon','authenticated') and not public.is_admin() then
    raise exception 'forbidden';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_orders on public.orders;
create trigger trg_guard_orders before update on public.orders
  for each row execute function public.guard_orders();

-- 4) Server-side order creation: prices, delivery, coupon and points are computed here.
create or replace function public.place_order(p_items jsonb, p_info jsonb, p_coupon text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_uid uuid:=auth.uid(); it jsonb; p record; c record;
  v_qty int; v_unit numeric; v_sub numeric:=0; v_disc numeric:=0; v_total numeric;
  v_delivery numeric:=4; v_pts int; v_ppd numeric; v_num text; v_oid uuid; v_rows jsonb:='[]'::jsonb; v_code text;
begin
  if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items) not between 1 and 50 then raise exception 'invalid_items'; end if;
  if length(coalesce(trim(p_info->>'name'),''))=0 or length(coalesce(trim(p_info->>'phone'),''))<6
     or length(coalesce(trim(p_info->>'city'),''))=0 or length(coalesce(trim(p_info->>'address'),''))=0 then raise exception 'invalid_info'; end if;
  if length(p_info::text)>4000 then raise exception 'invalid_info'; end if;
  for it in select * from jsonb_array_elements(p_items) loop
    select id,name,price,bundle_qty,bundle_price into p from public.products
      where id=(it->>'product_id')::uuid and is_active;
    if not found then raise exception 'product_unavailable'; end if;
    v_qty:=(it->>'qty')::int;
    if v_qty not between 1 and 500 then raise exception 'invalid_qty'; end if;
    if coalesce((it->>'is_bundle')::boolean,false) then
      if p.bundle_qty is null or p.bundle_qty<1 or v_qty % p.bundle_qty<>0 then raise exception 'invalid_bundle'; end if;
      v_unit:=round(p.bundle_price/p.bundle_qty,2);
    else v_unit:=p.price; end if;
    v_sub:=v_sub+v_unit*v_qty;
    v_rows:=v_rows||jsonb_build_object('product_id',p.id,'product_name',p.name,'unit_price',v_unit,'quantity',v_qty,
      'is_bundle',coalesce((it->>'is_bundle')::boolean,false),'bundle_label',case when coalesce((it->>'is_bundle')::boolean,false) then p.bundle_qty||'-pack' else '' end);
  end loop;
  v_code:=upper(trim(coalesce(p_coupon,'')));
  if v_code<>'' then
    select * into c from public.coupons where code=v_code and is_active for update;
    if not found or (c.expires_at is not null and c.expires_at<now()) or (c.max_uses is not null and c.used_count>=c.max_uses) then raise exception 'invalid_coupon'; end if;
    v_disc:=least(v_sub,case when c.discount_type='percent' then round(v_sub*c.discount_value/100,2) else c.discount_value end);
    update public.coupons set used_count=coalesce(used_count,0)+1 where code=v_code;
  end if;
  v_total:=round(v_sub+v_delivery-v_disc,2);
  select coalesce(points_per_dollar,7) into v_ppd from public.settings where id=1;
  v_pts:=round(v_total*coalesce(v_ppd,7));
  v_num:='DL-'||to_char(now(),'YYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
  insert into public.orders(order_number,user_id,status,full_name,phone,phone2,city,district,full_address,floor,notes,
      subtotal,delivery_fee,discount_amount,coupon_code,total,points_earned)
  values(v_num,v_uid,'confirmed',left(p_info->>'name',120),left(p_info->>'phone',40),left(coalesce(p_info->>'phone2',''),40),
      left(p_info->>'city',120),left(coalesce(p_info->>'district',''),120),left(p_info->>'address',500),left(coalesce(p_info->>'floor',''),40),
      left(coalesce(p_info->>'notes',''),1000),v_sub,v_delivery,v_disc,nullif(v_code,''),v_total,case when v_uid is null then 0 else v_pts end)
  returning id into v_oid;
  insert into public.order_items(order_id,product_id,product_name,unit_price,quantity,is_bundle,bundle_label)
    select v_oid,(r->>'product_id')::uuid,r->>'product_name',(r->>'unit_price')::numeric,(r->>'quantity')::int,(r->>'is_bundle')::boolean,r->>'bundle_label'
    from jsonb_array_elements(v_rows) r;
  if v_uid is not null then perform public.credit_points(v_uid,v_pts,'Order '||v_num); end if;
  return jsonb_build_object('id',v_oid,'order_number',v_num,'total',v_total,'points_earned',case when v_uid is null then 0 else v_pts end,'discount',v_disc);
end $$;

-- 5) Coupon preview without exposing the coupons table
create or replace function public.validate_coupon(p_code text, p_subtotal numeric)
returns numeric language plpgsql stable security definer set search_path=public as $$
declare c record;
begin
  select * into c from public.coupons where code=upper(trim(p_code)) and is_active;
  if not found or (c.expires_at is not null and c.expires_at<now()) or (c.max_uses is not null and c.used_count>=c.max_uses) then return null; end if;
  return least(p_subtotal,case when c.discount_type='percent' then round(p_subtotal*c.discount_value/100,2) else c.discount_value end);
end $$;

-- 6) Owner-only cancellation (reverses points server-side)
create or replace function public.cancel_order(p_order uuid, p_reason text default '')
returns void language plpgsql security definer set search_path=public as $$
declare o record;
begin
  select * into o from public.orders where id=p_order and user_id=auth.uid() for update;
  if not found then raise exception 'not_found'; end if;
  if o.status in ('cancelled','delivered') then raise exception 'not_cancellable'; end if;
  update public.orders set status='cancelled',cancel_reason=left(coalesce(p_reason,''),500) where id=p_order;
  if o.points_earned>0 then perform public.credit_points(o.user_id,-o.points_earned,'Order cancelled: '||o.order_number); end if;
end $$;

-- 7) Lock down privileged functions + direct writes (privilege REVOKEs only; reversible with GRANT).
revoke execute on function public.credit_points(uuid,int,text) from public, anon, authenticated;
revoke execute on function public.redeem_coupon(text) from public, anon, authenticated;
revoke insert on public.orders, public.order_items from anon, authenticated;
revoke select on public.coupons from anon, authenticated;
grant execute on function public.place_order(jsonb,jsonb,text) to anon, authenticated;
grant execute on function public.validate_coupon(text,numeric) to anon, authenticated;
grant execute on function public.cancel_order(uuid,text) to authenticated;
grant execute on function public.is_admin() to anon, authenticated;
-- NOTE: if credit_points has a different signature, adjust line 1 of section 7 (see pg_proc).

-- 8) delivery_locations: owner-only rows + coordinate sanity checks (NOT VALID => existing rows untouched)
alter table public.delivery_locations enable row level security;
do $$ begin
  if not exists(select 1 from pg_policies where tablename='delivery_locations' and policyname='dl_owner_all') then
    create policy dl_owner_all on public.delivery_locations for all to authenticated
      using (user_id=auth.uid()) with check (user_id=auth.uid());
  end if;
  if not exists(select 1 from pg_constraint where conname='dl_lat_lng_range') then
    alter table public.delivery_locations add constraint dl_lat_lng_range check
      ((latitude is null or latitude between -90 and 90) and (longitude is null or longitude between -180 and 180)) not valid;
  end if;
end $$;
