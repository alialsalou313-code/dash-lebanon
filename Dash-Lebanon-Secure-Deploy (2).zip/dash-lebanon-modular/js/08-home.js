/* =========================================================
   HOME PAGE — discover (hero + carousels) vs browse (grid)
========================================================= */
function pHome(){
  const discover=!S.forceGrid&&S.cat==='all'&&!S.search&&!S.offersOnly;
  return discover?pHomeDiscover():pHomeBrowse();
}
function pHomeDiscover(){
  const st=S.settings;
  const marqueeText=Array.from({length:8}).map(()=>'Shop now <b>↓</b>').join('');
  const cats=S.categories.filter(c=>S.products.some(p=>p.category_id===c.id));
  return `<div class="page">
    <div class="hero"><div class="hero-in">
      <div class="hero-eyebrow">Cash on delivery · anywhere in Lebanon</div>
      <h1>${heroHighlight(st.hero_title||'Shop smarter, live better.')}</h1>
      <p>${esc(st.hero_subtitle||'')}</p>
      <div class="hero-cta"><button class="btn btn-accent" onclick="viewAllCategory('offers')">See offers</button><button class="btn btn-ghost" style="background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.35)" onclick="viewAllCategory('all')">Shop all</button></div>
    </div></div>
    <div class="marquee"><div class="marquee-track">${marqueeText}${marqueeText}</div></div>
    ${cats.map(c=>catCarouselHTML(c)).join('')}
    ${compareTableHTML()}
  </div>`;
}
function heroHighlight(title){
  const words=esc(title).split(' ');
  if(words.length<2)return esc(title);
  const mid=Math.min(2,words.length-1);
  return words.map((w,i)=>i===mid?`<span class="hl">${w}</span>`:w).join(' ');
}
function catCarouselHTML(c){
  const items=S.products.filter(p=>p.category_id===c.id).slice(0,10);
  if(!items.length)return'';
  const rowId='car-'+c.id;
  return `<div class="cat-section">
    <div class="cat-section-title">${esc(c.name)}</div>
    <div class="carousel-wrap">
      <div class="carousel-track" id="${rowId}">${items.map(p=>productCardHTML(p)).join('')}</div>
    </div>
    <div class="carousel-nav">
      <button class="car-arrow" onclick="scrollRow('${rowId}',-1)" aria-label="Previous">‹</button>
      <button class="car-arrow" onclick="scrollRow('${rowId}',1)" aria-label="Next">›</button>
    </div>
    <div class="view-all-row"><button class="btn btn-ghost btn-pill btn-sm" onclick="viewAllCategory('${c.slug}')">View all</button></div>
  </div>`;
}
function scrollRow(id,dir){const el=document.getElementById(id);if(!el)return;el.scrollBy({left:dir*260,behavior:'smooth'})}
function compareTableHTML(){
  const rows=[
    ['Fast delivery, all over Lebanon','yes','yes','no'],
    ['Cash on delivery','yes','yes','no'],
    ['WhatsApp support','yes','no','no'],
    ['Loyalty points on every order','yes','no','no'],
    ['Easy order cancellation','yes','no','no'],
  ];
  return `<div class="card compare-wrap">
    <div class="compare-title">Why Dash Lebanon?</div>
    <table class="compare-table">
      <tr><th></th><th>Dash Lebanon</th><th>Some Stores</th><th>Others</th></tr>
      ${rows.map(r=>`<tr><td>${esc(r[0])}</td><td class="${r[1]==='yes'?'yes':'no'}">${r[1]==='yes'?'✓':'✕'}</td><td class="${r[2]==='yes'?'yes':'no'}">${r[2]==='yes'?'✓':'✕'}</td><td class="${r[3]==='yes'?'yes':'no'}">${r[3]==='yes'?'✓':'✕'}</td></tr>`).join('')}
    </table>
  </div>`;
}

/* ---- browse mode : search / tabs / sort / grid (unchanged mechanics) ---- */
function catLabel(cat){if(cat==='all')return'All';if(cat==='offers')return'Offers';const c=S.categories.find(x=>x.slug===cat);return c?c.name:cat}
function buildCatPills(){
  const items=[{slug:'all',name:'All'},...S.categories,{slug:'offers',name:'Offers'}];
  return items.map(c=>{
    const count=c.slug==='all'?S.products.length:c.slug==='offers'?S.products.filter(p=>p.compare_at_price>p.price||p.bundle_qty).length:S.products.filter(p=>p.category_id===c.id).length;
    return `<button class="pill ${S.cat===c.slug?'on':''}" onclick="setCat('${c.slug}')">${esc(c.name)} <span style="opacity:.6">${count}</span></button>`;
  }).join('');
}
function setCat(slug){S.cat=slug;S.offersOnly=(slug==='offers');document.getElementById('pgrid').innerHTML=buildGrid();document.getElementById('cats-row').innerHTML=buildCatPills()}
function setSort(s){S.sort=s;document.getElementById('pgrid').innerHTML=buildGrid();document.querySelectorAll('.sort-btn').forEach(b=>b.classList.toggle('on',b.dataset.sort===s))}
let searchDebounce;
function doSearch(v){
  S.search=v;
  document.getElementById('search-clr').classList.toggle('show',v.length>0);
  clearTimeout(searchDebounce);
  searchDebounce=setTimeout(()=>{document.getElementById('pgrid').innerHTML=buildGrid()},150);
}
function clearSearchInp(){S.search='';document.getElementById('search-field').value='';document.getElementById('search-clr').classList.remove('show');document.getElementById('pgrid').innerHTML=buildGrid()}

function filteredProducts(){
  let list=S.products;
  if(S.cat==='offers')list=list.filter(p=>p.compare_at_price>p.price||p.bundle_qty);
  else if(S.cat!=='all')list=list.filter(p=>{const c=S.categories.find(x=>x.slug===S.cat);return c&&p.category_id===c.id});
  const q=S.search.trim().toLowerCase();
  if(q)list=list.filter(p=>p.name.toLowerCase().includes(q)||(p.description||'').toLowerCase().includes(q));
  if(S.sort==='price_asc')list=[...list].sort((a,b)=>a.price-b.price);
  else if(S.sort==='price_desc')list=[...list].sort((a,b)=>b.price-a.price);
  else if(S.sort==='rating')list=[...list].sort((a,b)=>b.rating_avg-a.rating_avg);
  return list;
}
function buildGrid(){
  const list=filteredProducts();
  if(!S.products.length)return skeletonCards(8);
  if(!list.length)return `<div class="empty-box"><div class="empty-ico">🔍</div><div class="empty-ttl">No results${S.search?' for "'+esc(S.search)+'"':''}</div><div class="empty-sub">Try a different search or category.</div></div>`;
  return list.map(p=>productCardHTML(p)).join('');
}
function skeletonCards(n){return Array.from({length:n}).map(()=>`<div class="pcard"><div class="pcard-img skel"></div><div class="pcard-body"><div class="skel" style="height:12px;width:80%;border-radius:4px;margin-bottom:8px"></div><div class="skel" style="height:12px;width:50%;border-radius:4px"></div></div></div>`).join('')}
function productCardHTML(p){
  const disc=discPct(p.compare_at_price,p.price);
  const wished=isWished(p.id);
  const isBundle=!!p.bundle_qty;
  return `<div class="pcard" onclick="nav('product','${p.id}')">
    <div class="pcard-img">
      ${disc>0?`<div class="chip-corner">SAVE ${disc}%</div>`:''}
      ${isBundle?`<div class="chip-corner bundle">Bundle</div>`:''}
      <img src="${esc(coverImg(p))}" loading="lazy" alt="${esc(p.name)}" onerror="this.src='https://placehold.co/400x400/e7ebf3/98a2b8?text=No+Image'">
      <button class="wish-btn ${wished?'active':''}" data-pid="${p.id}" onclick="toggleWish('${p.id}',event)">${wished?'♥':'♡'}</button>
    </div>
    <div class="pcard-body">
      <div class="pcard-name">${esc(p.name)}</div>
      <div class="pcard-price-row">
        <div class="pcard-price">${isBundle?'From ':''}${fmt(p.price)}</div>
        ${p.compare_at_price?`<div class="pcard-old">${fmt(p.compare_at_price)}</div>`:''}
      </div>
      ${isBundle?`<button class="pcard-cta" onclick="event.stopPropagation();nav('product','${p.id}')">Choose options</button>`:`<button class="pcard-cta" onclick="quickAdd('${p.id}',event)">Add to cart</button>`}
      <div class="pcard-foot"><span>${p.rating_count?`<span class="stars">★</span> ${p.rating_avg}`:'New'}</span><span>+${calcEarnPts(p.price)}pts</span></div>
    </div>
  </div>`;
}
function pHomeBrowse(){
  const title=S.offersOnly?'Offers':(S.cat!=='all'?catLabel(S.cat):'All products');
  return `<div class="page">
    <button class="back-link" onclick="resetHome()">← Back to shopping</button>
    <div class="section-head"><div class="section-title">${esc(title)}</div></div>
    <div class="search-wrap">
      <span class="search-ico">🔍</span>
      <input class="search-inp" id="search-field" placeholder="Search products…" value="${esc(S.search)}" oninput="doSearch(this.value)">
      <button class="search-clr ${S.search?'show':''}" id="search-clr" onclick="clearSearchInp()">✕</button>
    </div>
    <div class="cats-row" id="cats-row">${buildCatPills()}</div>
    <div class="sort-row">
      <span style="font-size:.76rem;color:var(--muted);font-weight:600;font-family:var(--font-m)">Sort:</span>
      <button class="sort-btn on" data-sort="def" onclick="setSort('def')">Default</button>
      <button class="sort-btn" data-sort="price_asc" onclick="setSort('price_asc')">Price ↑</button>
      <button class="sort-btn" data-sort="price_desc" onclick="setSort('price_desc')">Price ↓</button>
      <button class="sort-btn" data-sort="rating" onclick="setSort('rating')">Top rated</button>
      <span class="result-count" id="result-count">${filteredProducts().length} items</span>
    </div>
    <div class="grid" id="pgrid">${buildGrid()}</div>
  </div>`;
}
function bindHome(){}
