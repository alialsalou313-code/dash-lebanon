/* =========================================================
   MOBILE NAV — bottom bar with a single sliding active circle,
   center "+" quick-action sheet.
========================================================= */
const MN_TABS=['home','orders',null,'chat','profile'];
function mnActive(){
  if(typeof AI!=='undefined'&&AI.open)return'chat';
  const p=S.page;
  if(p==='admin'||p==='admin-login')return null;
  if(p==='orders'||p==='order-detail')return'orders';
  if(p==='account'||p==='points')return'profile';
  return'home';
}
function updateMobileNav(){
  const a=mnActive(),bar=document.getElementById('mobile-nav'),dot=document.getElementById('mn-dot');
  if(!bar)return;
  bar.classList.toggle('hide-nav',a===null);
  document.body.classList.toggle('has-mnav',a!==null);
  document.querySelectorAll('[data-mnav]').forEach(el=>{const on=el.dataset.mnav===a;el.classList.toggle('on',on);el.setAttribute('aria-current',on?'page':'false')});
  const i=MN_TABS.indexOf(a);
  if(dot){dot.style.opacity=i<0?0:1;if(i>=0)dot.style.transform=`translateX(${i*100}%)`}
}
function mnGo(t){
  closePlusSheet();
  if(t==='home')resetHome();
  else if(t==='orders')nav('orders');
  else if(t==='profile')nav('account');
  else if(t==='chat'){toggleAiPanel();setTimeout(updateMobileNav,0)}
}
function openPlusSheet(){
  const n=cartCount();
  document.getElementById('plus-sheet').innerHTML=`<div class="modal-handle"></div><div class="ps-title">Quick actions</div>
  <button onclick="closePlusSheet();${n?"nav('checkout')":"viewAllCategory('all')"}"><span>🛍️</span><b>Add order</b><small>${n?n+' item'+(n>1?'s':'')+' ready to checkout':'Browse products'}</small></button>
  <button onclick="closePlusSheet();openDeliveryLocationEditor()"><span>📍</span><b>Add address</b><small>${S.deliveryLocation?.confirmed_at?'Change delivery location':'Use GPS or type it'}</small></button>
  <button onclick="closePlusSheet();openSearch()"><span>🔍</span><b>Search</b><small>Find a product</small></button>
  <button onclick="closePlusSheet();nav('cart')"><span>🛒</span><b>Cart</b><small>${n} in cart</small></button>
  <button onclick="closePlusSheet();nav('wishlist')"><span>♡</span><b>Favorites</b><small>Saved products</small></button>
  <button onclick="closePlusSheet();nav('contact')"><span>✉️</span><b>Contact us</b><small>We reply fast</small></button>`;
  document.getElementById('plus-ov').classList.add('open');document.getElementById('plus-sheet').classList.add('open');
  document.getElementById('mn-plus').classList.add('on');
}
function closePlusSheet(){
  ['plus-ov','plus-sheet'].forEach(id=>document.getElementById(id)?.classList.remove('open'));
  document.getElementById('mn-plus')?.classList.remove('on');
}
function togglePlusSheet(){document.getElementById('plus-sheet').classList.contains('open')?closePlusSheet():openPlusSheet()}
/* keep the active circle in sync with every navigation / panel change */
(function(){
  const _nav=window.nav;window.nav=function(){const r=_nav.apply(this,arguments);updateMobileNav();return r};
  const _close=window.closeAiPanel;window.closeAiPanel=function(){_close();updateMobileNav()};
  window.addEventListener('popstate',()=>setTimeout(updateMobileNav,0));
  window.addEventListener('DOMContentLoaded',()=>setTimeout(updateMobileNav,0));
})();
