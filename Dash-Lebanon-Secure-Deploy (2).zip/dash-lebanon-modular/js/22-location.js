/* =========================================================
   LOCATION — permission prompt, automatic (GPS + reverse geocoding),
   manual entry, confirmation, saved address. No background tracking:
   position is read once, only after the user taps "Allow"/"Use my location".
========================================================= */
const LOC_ASKED_KEY='dl_loc_asked';
let locDraft=null; // {latitude,longitude,city,district,address,source}
let locReturnToAi=false;

function locEsc(s){return esc(s)}
function locSheet(html){document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet loc-sheet" onclick="event.stopPropagation()"><div class="modal-handle"></div>${html}</div></div>`}

/* First visit only: explain why, then let the user decide. */
async function maybePromptLocation(){
  try{
    if(localStorage.getItem(LOC_ASKED_KEY)||S.deliveryLocation?.confirmed_at||!navigator.geolocation)return;
    if(navigator.permissions){const st=await navigator.permissions.query({name:'geolocation'});if(st.state==='denied'){localStorage.setItem(LOC_ASKED_KEY,'denied');return}}
  }catch(e){}
  setTimeout(()=>{if(S.page==='admin'||S.page==='admin-login')return;
    locSheet(`<div class="loc-hero">📍</div><div class="modal-title">Allow location access</div>
    <p class="muted-note loc-copy">We use your location only to fill in your delivery address when you order. It is read once, never tracked in the background, and you can always type the address instead.</p>
    <button class="btn btn-primary" onclick="locAnswer('allow')">Allow location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="locAnswer('later')">Not now</button>`)},1500);
}
function locAnswer(a){localStorage.setItem(LOC_ASKED_KEY,a==='allow'?'1':'later');if(a==='allow')openDeliveryLocationEditor(false,'auto');else closeModal()}

function locGetPosition(){
  return new Promise((resolve,reject)=>{
    if(!navigator.geolocation)return reject({code:'unsupported'});
    navigator.geolocation.getCurrentPosition(p=>resolve(p.coords),e=>reject({code:e.code===1?'denied':e.code===3?'timeout':'unavailable'}),{enableHighAccuracy:true,timeout:15000,maximumAge:60000});
  });
}
async function locReverse(latitude,longitude){
  if(typeof DELIVERY_REVERSE_GEOCODING_READY!=='undefined'&&DELIVERY_REVERSE_GEOCODING_READY){
    const{data,error}=await sb.functions.invoke('reverse-geocode',{body:{latitude,longitude}});
    if(!error&&data?.address)return{city:data.city||data.region||'',district:data.district||'',address:data.address};
  }
  const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=en&lat=${encodeURIComponent(latitude)}&lon=${encodeURIComponent(longitude)}`);
  if(!r.ok)throw new Error('geocode_failed');
  const j=await r.json(),a=j.address||{};
  return{city:a.state||a.city||a.town||'',district:a.suburb||a.neighbourhood||a.village||a.town||a.city||'',address:j.display_name||''};
}

function openDeliveryLocationEditor(returnToAi=false,mode){
  locReturnToAi=returnToAi;
  const saved=S.deliveryLocation;
  mode=mode||(saved?.confirmed_at?'saved':(navigator.geolocation?'auto':'manual'));
  if(mode==='saved'){
    locSheet(`<div class="modal-title">📍 Saved delivery location</div>
    <div class="loc-card"><strong>${locEsc(saved.city||'')}${saved.district?' · '+locEsc(saved.district):''}</strong><div class="muted-note">${locEsc(saved.full_address||'')}</div></div>
    <button class="btn btn-primary" onclick="closeModal();${locReturnToAi?'aiOrderDialog()':'void 0'}">Use this location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="openDeliveryLocationEditor(${locReturnToAi},'auto')">Change</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="deleteDeliveryLocation()">Remove saved address</button>`);return;
  }
  const auto=mode==='auto';
  locSheet(`<div class="modal-title">📍 Delivery location</div>
  <div class="loc-choice"><label class="${auto?'on':''}" onclick="openDeliveryLocationEditor(${locReturnToAi},'auto')"><input type="radio" name="lm" ${auto?'checked':''}> <span><b>Automatic</b><small>Use my current location</small></span></label>
  <label class="${auto?'':'on'}" onclick="openDeliveryLocationEditor(${locReturnToAi},'manual')"><input type="radio" name="lm" ${auto?'':'checked'}> <span><b>Enter manually</b><small>Type your address</small></span></label></div>
  <div id="loc-body"></div>`);
  if(auto)locRunAuto();else locManualForm();
}
let locRunId=0;
async function locRunAuto(){
  const body=document.getElementById('loc-body'),id=++locRunId;
  body.innerHTML=`<div class="loc-status"><div class="spin spin-dark"></div> Finding your location…</div><button class="btn btn-ghost" onclick="locRunId++;locManualForm()">Enter address manually</button>`;
  try{
    const c=await locGetPosition();
    if(id!==locRunId)return;
    locDraft={latitude:+c.latitude.toFixed(6),longitude:+c.longitude.toFixed(6),source:'geolocation'};
    let g={city:'',district:'',address:''};
    try{g=await locReverse(locDraft.latitude,locDraft.longitude)}catch(e){}
    if(id!==locRunId)return;
    Object.assign(locDraft,g);
    if(!g.address){locManualForm('We found you but could not read the address. Please type it.');return}
    body.innerHTML=`<div class="loc-card"><div class="muted-note">Is this your delivery location?</div><strong>${locEsc(g.address)}</strong></div>
    <button class="btn btn-primary" onclick="locConfirmAuto()">Confirm location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="locManualForm('',true)">Change location</button>`;
  }catch(e){
    if(id!==locRunId)return;
    const msg={denied:'Location permission was denied. You can enter the address manually.',timeout:'Locating took too long. Try again or enter it manually.',unavailable:'Your location is unavailable right now. Enter it manually.',unsupported:'This browser does not support location. Enter it manually.'}[e.code]||'Could not get your location.';
    locManualForm(msg);
  }
}
function locManualForm(msg,keep){
  const body=document.getElementById('loc-body');if(!body)return;
  const d=keep&&locDraft?locDraft:(S.deliveryLocation||{});
  if(!keep)locDraft=null;
  body.innerHTML=`${msg?`<div class="alert alert-err">${locEsc(msg)}</div>`:''}
  <div class="fgroup"><label class="flabel">City / governorate <span class="req">*</span></label><input class="finput" id="dl-city" maxlength="120" value="${locEsc(d.city||'')}"></div>
  <div class="fgroup"><label class="flabel">District / area</label><input class="finput" id="dl-district" maxlength="120" value="${locEsc(d.district||'')}"></div>
  <div class="fgroup"><label class="flabel">Full address <span class="req">*</span></label><textarea class="ftextarea" id="dl-address" maxlength="500">${locEsc(d.full_address||d.address||'')}</textarea></div>
  <button class="btn btn-primary" id="dl-save" onclick="saveDeliveryLocation()">Confirm and save address</button>`;
}
function locConfirmAuto(){
  const d=locDraft;if(!d)return;
  persistDeliveryLocation({city:d.city,district:d.district,full_address:d.address,latitude:d.latitude,longitude:d.longitude,source:'geolocation'});
}
function saveDeliveryLocation(){
  const city=document.getElementById('dl-city').value.trim().slice(0,120),district=document.getElementById('dl-district').value.trim().slice(0,120),full_address=document.getElementById('dl-address').value.trim().slice(0,500);
  if(!city||!full_address){toast('Enter the city and full address');return}
  const keepGps=locDraft&&locDraft.address===full_address&&locDraft.city===city;
  persistDeliveryLocation({city,district,full_address,latitude:keepGps?locDraft.latitude:null,longitude:keepGps?locDraft.longitude:null,source:keepGps?'geolocation':'manual'});
}
async function persistDeliveryLocation(l){
  const now=new Date().toISOString();
  const loc={user_id:S.session?.user?.id||null,...l,confirmed_at:now,updated_at:now};
  if(S.session){
    const{error}=await sb.from('delivery_locations').upsert(loc,{onConflict:'user_id'});
    if(error){console.error(error);toast('Could not save the address to your account');return}
  }
  S.deliveryLocation=loc;locDraft=null;closeModal();toast(S.session?'Delivery address saved':'Address confirmed for this order');
  if(locReturnToAi){locReturnToAi=false;aiOrderDialog()}
  else if(S.page==='account')renderAccountLoggedIn();
  else if(S.page==='checkout')rerenderCheckoutKeepInputs();
}
function rerenderCheckoutKeepInputs(){
  const ids=['co-name','co-phone','co-phone2','co-floor','co-notes','co-coupon'],v=Object.fromEntries(ids.map(i=>[i,document.getElementById(i)?.value||'']));
  render();ids.forEach(i=>{const el=document.getElementById(i);if(el&&v[i])el.value=v[i]});
}
async function deleteDeliveryLocation(){
  if(S.session){const{error}=await sb.from('delivery_locations').delete().eq('user_id',S.session.user.id);if(error){toast('Could not remove the address');return}}
  S.deliveryLocation=null;locDraft=null;closeModal();toast('Address removed');
  if(S.page==='account')renderAccountLoggedIn();else if(S.page==='checkout')rerenderCheckoutKeepInputs();
}
