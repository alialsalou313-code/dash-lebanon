/* =========================================================
   ORDERS / TRACKING
========================================================= */
async function pOrders(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your orders');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data}=await sb.from('orders').select('*, order_items(*)').eq('user_id',S.session.user.id).order('created_at',{ascending:false});
  const orders=data||[];
  if(!orders.length){app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="empty-box"><div class="empty-ico">📦</div><div class="empty-ttl">No orders yet</div><div class="empty-sub">Your orders will show up here.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div></div>`;return}
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-title" style="margin-bottom:14px">My Orders</div>
    ${orders.map(o=>`<div class="card order-row" onclick="nav('order-detail','${o.id}')" style="cursor:pointer">
      <div class="order-head"><div><div class="order-num">${esc(o.order_number)}</div><div class="order-date">${new Date(o.created_at).toLocaleDateString()}</div></div><span class="status-badge st-${o.status}">${o.status}</span></div>
      <div style="font-size:.83rem;color:var(--muted)">${o.order_items.length} item${o.order_items.length>1?'s':''} · ${fmt(o.total)}</div>
    </div>`).join('')}
  </div>`;
}
async function pOrderDetail(){
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:o}=await sb.from('orders').select('*, order_items(*)').eq('id',S.data).maybeSingle();
  if(!o){nav('orders');return}
  const steps=['pending','confirmed','processing','shipping','delivered'];
  const cur=steps.indexOf(o.status);
  const cancelled=o.status==='cancelled';
  const canCancel=!cancelled&&o.status!=='delivered';
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-head"><div class="section-title" style="font-size:1.1rem">${esc(o.order_number)}</div><span class="status-badge st-${o.status}">${o.status}</span></div>
    ${!cancelled?`<div class="card" style="padding:18px 14px;margin-bottom:14px"><div class="track-steps">${steps.map((s,i)=>`<div class="track-step"><div class="track-dot ${i<=cur?'done':''}">${i<=cur?'✓':i+1}</div><div class="track-lbl">${s}</div></div>`).join('')}</div></div>`:
    `<div class="alert alert-err">This order was cancelled.${o.cancel_reason?' Reason: '+esc(o.cancel_reason):''}</div>`}
    <div class="card" style="padding:18px;margin-bottom:14px">
      <div class="form-title">Items</div>
      ${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)}${i.is_bundle?' ('+esc(i.bundle_label)+')':''} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}
      <div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>
      ${o.discount_amount>0?`<div class="summary-row"><span>Discount</span><span style="color:var(--success)">-${fmt(o.discount_amount)}</span></div>`:''}
      <div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div>
      <div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div>
    </div>
    <div class="card" style="padding:18px;margin-bottom:14px">
      <div class="form-title">Delivery details</div>
      <div class="summary-row"><span>Name</span><span>${esc(o.full_name)}</span></div>
      <div class="summary-row"><span>Phone</span><span>${esc(o.phone)}</span></div>
      <div class="summary-row"><span>Address</span><span style="text-align:right">${esc(o.city)}, ${esc(o.district)} — ${esc(o.full_address)}</span></div>
    </div>
    ${canCancel?`<button class="btn btn-danger" onclick="cancelOrder('${o.id}','${esc(o.order_number)}','${o.created_at}')">Cancel order</button>`:''}
  </div>`;
}
async function cancelOrder(id,num,createdAt){
  const hoursSince=(Date.now()-new Date(createdAt).getTime())/3600000;
  const late=hoursSince>(S.settings.free_cancel_hours||24);
  const reason=prompt(late?`This order is past the free-cancellation window (${S.settings.free_cancel_hours}h). A $${S.settings.cancel_fee} fee may apply — our team will follow up. Add a reason (optional):`:'Add a cancellation reason (optional):')||'';
  if(reason===null)return;
  await sb.from('orders').update({status:'cancelled',cancel_reason:reason}).eq('id',id);
  const{data:o}=await sb.from('orders').select('points_earned,user_id').eq('id',id).maybeSingle();
  if(o&&o.user_id&&o.points_earned){
    await sb.rpc('credit_points',{p_user:o.user_id,p_points:-o.points_earned,p_note:'Order cancelled: '+num});
  }
  toast('Order cancelled');nav('orders',null,false);
}
