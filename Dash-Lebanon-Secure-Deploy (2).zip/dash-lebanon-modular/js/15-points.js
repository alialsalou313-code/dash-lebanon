/* =========================================================
   POINTS PAGE
========================================================= */
function tierFor(pts){if(pts>=3000)return{name:'Platinum',pct:8};if(pts>=1500)return{name:'Gold',pct:5};if(pts>=500)return{name:'Silver',pct:3};return{name:'Bronze',pct:0}}
async function pPoints(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your points');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:hist}=await sb.from('points_history').select('*').eq('user_id',S.session.user.id).order('created_at',{ascending:false}).limit(20);
  const pts=S.profile?.loyalty_points||0;const tier=tierFor(pts);
  const next=pts>=3000?null:pts>=1500?3000:pts>=500?1500:500;
  const tiers=[{n:'Bronze',req:'0–499',pct:0},{n:'Silver',req:'500–1499',pct:3},{n:'Gold',req:'1500–2999',pct:5},{n:'Platinum',req:'3000+',pct:8}];
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="pts-hero"><div style="font-size:.83rem;opacity:.8;font-family:var(--font-m)">Total points</div><div class="pts-hero-num">${pts}</div><div class="rank-badge">${tier.name}</div>${next?`<div style="font-size:.76rem;margin-top:9px;opacity:.85;font-family:var(--font-m)">${next-pts} pts to next tier</div>`:''}</div>
    <div class="tiers">${tiers.map(t=>`<div class="card tier ${t.n===tier.name?'on':''}"><div class="tier-name">${t.n}</div><div class="tier-req">${t.req} pts</div><div class="tier-pct">${t.pct>0?t.pct+'% off':'—'}</div></div>`).join('')}</div>
    <div class="card" style="padding:18px">
      <div class="form-title">Points history</div>
      ${(hist&&hist.length)?hist.map(h=>`<div class="summary-row"><span>${esc(h.note||'Activity')}<br><span style="font-size:.7rem;color:var(--muted)">${new Date(h.created_at).toLocaleDateString()}</span></span><span style="font-weight:800;color:${h.points>0?'var(--success)':'var(--danger)'}">${h.points>0?'+':''}${h.points}</span></div>`).join(''):`<div style="color:var(--muted);font-size:.85rem;padding:10px 0">No activity yet</div>`}
    </div>
  </div>`;
}
