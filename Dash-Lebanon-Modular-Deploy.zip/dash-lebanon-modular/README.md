# Dash Lebanon — Modular Deploy Build

Static-hosting-ready modularization of the supplied Dash Lebanon HTML project.

## Structure
- `index.html` — application shell and static layout
- `css/` — base, admin, AI and responsive/mobile navigation styles
- `js/` — JavaScript split by responsibility/page
- `views/` — static shell reference for future page extraction

## Deploy
Upload the entire folder to Netlify/Cloudflare Pages/any static host. `index.html` is the entry point.

## Important
- Supabase uses the browser-safe anon key already present in the source. Never place a Supabase service-role key in frontend files.
- Firebase/OTP frontend code was removed from this modular build; authentication is direct Supabase email/password.
- Admin authorization must still be enforced by Supabase RLS/database policies, not by frontend code.
- AI image attachments are sent to the existing `ai-chat` Edge Function as `images`; the Edge Function must accept/forward multimodal image data for actual vision processing.
- Automatic location is permission-based and remains optional; manual delivery address remains available.
